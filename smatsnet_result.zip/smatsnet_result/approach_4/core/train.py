import os
import logging
import torch
import torch.utils.data
import torch.nn.functional as F

import utils.data_loaders
import utils.data_transforms
import utils.helpers

from datetime import datetime as dt
from tensorboardX import SummaryWriter

from utils.average_meter import AverageMeter
from utils.amp import get_autocast, get_grad_scaler
from core.test import test_net

from models.encoder import ShuffleNetEncoder, MobileNetV3Encoder, EfficientNetB0Encoder
from models.ensembler import RobustEnsembler
from models.decoder import Decoder
from models.merger import CrossAttentionMerger
from models.refiner import Refiner


def train_net(cfg):
    IMG_SIZE = cfg.CONST.IMG_H, cfg.CONST.IMG_W
    CROP_SIZE = cfg.CONST.CROP_IMG_H, cfg.CONST.CROP_IMG_W

    train_tf = utils.data_transforms.Compose([
        utils.data_transforms.RandomCrop(IMG_SIZE, CROP_SIZE),
        utils.data_transforms.RandomBackground(cfg.TRAIN.RANDOM_BG_COLOR_RANGE),
        utils.data_transforms.ColorJitter(cfg.TRAIN.BRIGHTNESS, cfg.TRAIN.CONTRAST, cfg.TRAIN.SATURATION),
        utils.data_transforms.RandomNoise(cfg.TRAIN.NOISE_STD),
        utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
        utils.data_transforms.RandomFlip(),
        utils.data_transforms.RandomPermuteRGB(),
        utils.data_transforms.ToTensor(),
    ])

    val_tf = utils.data_transforms.Compose([
        utils.data_transforms.CenterCrop(IMG_SIZE, CROP_SIZE),
        utils.data_transforms.RandomBackground(cfg.TEST.RANDOM_BG_COLOR_RANGE),
        utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
        utils.data_transforms.ToTensor(),
    ])

    train_loader = torch.utils.data.DataLoader(
        dataset=utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TRAIN_DATASET](cfg).get_dataset(
            utils.data_loaders.DatasetType.TRAIN, cfg.CONST.N_VIEWS_RENDERING, train_tf),
        batch_size=cfg.CONST.BATCH_SIZE, num_workers=cfg.CONST.NUM_WORKER,
        pin_memory=True, shuffle=True, drop_last=True
    )

    val_loader = torch.utils.data.DataLoader(
        dataset=utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TEST_DATASET](cfg).get_dataset(
            utils.data_loaders.DatasetType.VAL, cfg.CONST.N_VIEWS_RENDERING, val_tf),
        batch_size=1, num_workers=cfg.CONST.NUM_WORKER,
        pin_memory=True, shuffle=False
    )

    enc1 = ShuffleNetEncoder(cfg, variant="x0_5", use_imagenet_weights=True)
    enc2 = MobileNetV3Encoder(cfg, use_imagenet_weights=True)
    enc3 = EfficientNetB0Encoder(cfg, use_imagenet_weights=True)

    # Tiny ViT refinement enabled here:
    ens = RobustEnsembler(n_experts=3, c=256, vit_blocks=1, vit_heads=4, vit_mlp_ratio=2.0, dropout=0.1)

    dec = Decoder(cfg)
    mrg = CrossAttentionMerger(cfg, heads=4)
    rfn = Refiner(cfg)

    ens.apply(utils.helpers.init_weights)
    dec.apply(utils.helpers.init_weights)
    mrg.apply(utils.helpers.init_weights)
    rfn.apply(utils.helpers.init_weights)

    if torch.cuda.is_available():
        enc1 = torch.nn.DataParallel(enc1).cuda()
        enc2 = torch.nn.DataParallel(enc2).cuda()
        enc3 = torch.nn.DataParallel(enc3).cuda()
        ens = torch.nn.DataParallel(ens).cuda()
        dec = torch.nn.DataParallel(dec).cuda()
        mrg = torch.nn.DataParallel(mrg).cuda()
        rfn = torch.nn.DataParallel(rfn).cuda()

    autocast_cm = get_autocast()
    scaler = get_grad_scaler()
    loss_fn = torch.nn.BCEWithLogitsLoss()  # AMP-safe [web:225]

    params = list(enc1.parameters()) + list(enc2.parameters()) + list(enc3.parameters()) + \
             list(ens.parameters()) + list(dec.parameters()) + list(mrg.parameters()) + list(rfn.parameters())

    opt = torch.optim.Adam(params, lr=cfg.TRAIN.LEARNING_RATE, betas=cfg.TRAIN.BETAS, foreach=False)
    sch = torch.optim.lr_scheduler.MultiStepLR(opt, milestones=cfg.TRAIN.LR_MILESTONES, gamma=cfg.TRAIN.GAMMA)

    ts = dt.now().isoformat().replace(':', '-')
    out_dir = os.path.join(cfg.DIR.OUT_PATH, '%s', ts)
    cfg.DIR.LOGS = out_dir % 'logs'
    cfg.DIR.CHECKPOINTS = out_dir % 'checkpoints'
    os.makedirs(cfg.DIR.LOGS, exist_ok=True)
    os.makedirs(cfg.DIR.CHECKPOINTS, exist_ok=True)

    tr_w = SummaryWriter(os.path.join(cfg.DIR.LOGS, 'train'))
    te_w = SummaryWriter(os.path.join(cfg.DIR.LOGS, 'test'))

    best_iou = -1
    best_epoch = -1

    for epoch in range(cfg.TRAIN.NUM_EPOCHS):
        enc1.train(); enc2.train(); enc3.train()
        ens.train(); dec.train(); mrg.train(); rfn.train()

        for b, (_, _, imgs, gt32) in enumerate(train_loader):
            imgs = utils.helpers.var_or_cuda(imgs)
            gt32 = utils.helpers.var_or_cuda(gt32)
            gt16 = F.interpolate(gt32.unsqueeze(1), size=(16, 16, 16), mode="trilinear", align_corners=False).squeeze(1)

            opt.zero_grad(set_to_none=True)

            with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
                f1 = enc1(imgs)
                f2 = enc2(imgs)
                f3 = enc3(imgs)
                fused = ens([f1, f2, f3])

                raw32, logits16, logits32 = dec(fused)
                fused16, fused32 = mrg(raw32, logits16, logits32)

                loss16 = loss_fn(fused16, gt16)
                loss32 = loss_fn(fused32, gt32)
                encoder_loss = (0.3 * loss16 + 1.0 * loss32) * 10

                refined32 = rfn(fused32)
                refiner_loss = loss_fn(refined32, gt32) * 10

                loss = refiner_loss + 0.2 * encoder_loss

            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()

            itr = epoch * len(train_loader) + b
            tr_w.add_scalar("Loss/Encoder", encoder_loss.item(), itr)
            tr_w.add_scalar("Loss/Refiner", refiner_loss.item(), itr)

            if b % 20 == 0:
                logging.info("[E %d][B %d/%d] EncLoss=%.4f RefLoss=%.4f",
                             epoch + 1, b + 1, len(train_loader), encoder_loss.item(), refiner_loss.item())

        sch.step()

        iou = test_net(cfg, epoch + 1, val_loader, te_w, enc1, enc2, enc3, ens, dec, mrg, rfn)
        is_best = iou > best_iou
        if is_best:
            best_iou = iou
            best_epoch = epoch

        if ((epoch + 1) % cfg.TRAIN.SAVE_FREQ == 0) or is_best:
            name = "checkpoint-best.pth" if is_best else f"checkpoint-epoch-{epoch+1:03d}.pth"
            path = os.path.join(cfg.DIR.CHECKPOINTS, name)
            torch.save({
                "epoch": epoch,
                "best_iou": best_iou,
                "best_epoch": best_epoch,
                "enc1": enc1.state_dict(),
                "enc2": enc2.state_dict(),
                "enc3": enc3.state_dict(),
                "ens": ens.state_dict(),
                "dec": dec.state_dict(),
                "mrg": mrg.state_dict(),
                "rfn": rfn.state_dict(),
                "opt": opt.state_dict(),
                "scaler": scaler.state_dict(),
            }, path)
            logging.info("Saved: %s", path)

    tr_w.close()
    te_w.close()
