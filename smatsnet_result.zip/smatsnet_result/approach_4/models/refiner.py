import torch
import torch.nn as nn

class Refiner(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        leaky = cfg.NETWORK.LEAKY_VALUE
        use_bias = cfg.NETWORK.TCONV_USE_BIAS

        self.e1 = nn.Sequential(nn.Conv3d(1, 32, 4, padding=2), nn.BatchNorm3d(32), nn.LeakyReLU(leaky, True), nn.MaxPool3d(2))
        self.e2 = nn.Sequential(nn.Conv3d(32, 64, 4, padding=2), nn.BatchNorm3d(64), nn.LeakyReLU(leaky, True), nn.MaxPool3d(2))
        self.e3 = nn.Sequential(nn.Conv3d(64, 128, 4, padding=2), nn.BatchNorm3d(128), nn.LeakyReLU(leaky, True), nn.MaxPool3d(2))

        self.fc1 = nn.Sequential(nn.Linear(8192, 2048), nn.ReLU(True))
        self.fc2 = nn.Sequential(nn.Linear(2048, 8192), nn.ReLU(True))

        self.d1 = nn.Sequential(nn.ConvTranspose3d(128, 64, 4, 2, 1, bias=use_bias), nn.BatchNorm3d(64), nn.ReLU(True))
        self.d2 = nn.Sequential(nn.ConvTranspose3d(64, 32, 4, 2, 1, bias=use_bias), nn.BatchNorm3d(32), nn.ReLU(True))
        self.out = nn.ConvTranspose3d(32, 1, 4, 2, 1, bias=True)

    def forward(self, coarse_logits):
        x0 = coarse_logits.unsqueeze(1)
        x16 = self.e1(x0)
        x8  = self.e2(x16)
        x4  = self.e3(x8)

        flat = self.fc1(x4.view(-1, 8192))
        flat = self.fc2(flat)
        x4r = x4 + flat.view(-1, 128, 4, 4, 4)

        x8r = x8 + self.d1(x4r)
        x16r = x16 + self.d2(x8r)

        out_logits = (x0 + self.out(x16r)) * 0.5
        return out_logits.squeeze(1)
