import torch
import torch.nn as nn
import torch.nn.functional as F

class CrossAttentionMerger(nn.Module):
    def __init__(self, cfg, heads=4, dropout=0.1):
        super().__init__()
        leaky = cfg.NETWORK.LEAKY_VALUE

        self.score_net = nn.Sequential(
            nn.Conv3d(9, 16, 3, padding=1, bias=False),
            nn.BatchNorm3d(16),
            nn.LeakyReLU(leaky, inplace=True),
            nn.Conv3d(16, 1, 1, bias=True)
        )

        self.view_attn = nn.MultiheadAttention(embed_dim=32, num_heads=heads, dropout=dropout, batch_first=True)
        self.view_proj = nn.Linear(32, 1)

    def forward(self, raw32, logits16, logits32):
        B, V = logits32.shape[:2]

        # Context-aware voxel weights
        scores = []
        for i in range(V):
            s = self.score_net(raw32[:, i])     # [B,1,32,32,32]
            scores.append(s.squeeze(1))
        scores = torch.stack(scores, dim=1)     # [B,V,32,32,32]
        w_voxel32 = F.softmax(scores, dim=1)

        fused32_ctx = torch.sum(w_voxel32 * logits32, dim=1)

        w_voxel16 = F.interpolate(w_voxel32, size=(16, 16, 16), mode="trilinear", align_corners=False)
        fused16_ctx = torch.sum(w_voxel16 * logits16, dim=1)

        # Global view-attention weights
        m = logits32.mean(dim=(2, 3, 4))
        sd = logits32.std(dim=(2, 3, 4))
        a = logits32.abs().mean(dim=(2, 3, 4))
        tok = torch.stack([m, sd, a, m * a], dim=-1)     # [B,V,4]
        tok = F.pad(tok, (0, 28), value=0.0)             # [B,V,32]

        attn_out, _ = self.view_attn(tok, tok, tok)      # [B,V,32]
        attn_logits = self.view_proj(attn_out).squeeze(-1)  # [B,V]
        w_view = F.softmax(attn_logits, dim=1)              # [B,V]

        w_view32 = w_view.view(B, V, 1, 1, 1)               # broadcast-safe
        fused32_attn = torch.sum(w_view32 * logits32, dim=1)

        w_view16 = F.interpolate(w_view32, size=(16, 16, 16), mode="trilinear", align_corners=False)
        fused16_attn = torch.sum(w_view16 * logits16, dim=1)

        fused32 = 0.7 * fused32_ctx + 0.3 * fused32_attn
        fused16 = 0.7 * fused16_ctx + 0.3 * fused16_attn
        return fused16, fused32
