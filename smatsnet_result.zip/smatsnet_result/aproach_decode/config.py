from easydict import EasyDict as edict
__C = edict()
cfg = __C

__C.DATASETS = edict()
__C.DATASETS.SHAPENET = edict()
__C.DATASETS.SHAPENET.TAXONOMY_FILE_PATH = 'C://smatsnet//dataset//shapenet.json'
__C.DATASETS.SHAPENET.RENDERING_PATH = 'C://smatsnet//dataset//ShapeNetRendering//%s//%s//%s//%02d.png'
__C.DATASETS.SHAPENET.VOXEL_PATH = 'C://smatsnet//dataset//ShapeNetVox32//%s//%s//model.binvox'

__C.DATASET = edict()
__C.DATASET.MEAN = [0.5, 0.5, 0.5]
__C.DATASET.STD = [0.5, 0.5, 0.5]
__C.DATASET.TRAIN_DATASET = 'ShapeNet'
__C.DATASET.TEST_DATASET = 'ShapeNet'

__C.CONST = edict()
__C.CONST.DEVICE = '0'
__C.CONST.RNG_SEED = 0
__C.CONST.IMG_W = 224
__C.CONST.IMG_H = 224
__C.CONST.CROP_IMG_W = 128
__C.CONST.CROP_IMG_H = 128

__C.CONST.N_VIEWS_RENDERING =1
__C.CONST.BATCH_SIZE =  64
__C.CONST.NUM_WORKER = 4

__C.DIR = edict()
__C.DIR.OUT_PATH = './output'
__C.DIR.RANDOM_BG_PATH = '/home/hzxie/Datasets/SUN2012/JPEGImages'

__C.NETWORK = edict()
__C.NETWORK.LEAKY_VALUE = .2
__C.NETWORK.TCONV_USE_BIAS = False
__C.NETWORK.USE_REFINER = True
__C.NETWORK.USE_MERGER = True

__C.TRAIN = edict()
__C.TRAIN.RESUME_TRAIN = False
__C.TRAIN.NUM_EPOCHS = 200
__C.TRAIN.BRIGHTNESS = .4
__C.TRAIN.CONTRAST = .4
__C.TRAIN.SATURATION = .4
__C.TRAIN.NOISE_STD = .1
__C.TRAIN.RANDOM_BG_COLOR_RANGE = [[225,255],[225,255],[225,255]]

__C.TRAIN.POLICY = 'adam'
__C.TRAIN.LEARNING_RATE = 1e-4
__C.TRAIN.BETAS = (.9, .999)
__C.TRAIN.LR_MILESTONES = [80, 120]
__C.TRAIN.GAMMA = 0.5
__C.TRAIN.SAVE_FREQ = 5

__C.TEST = edict()
__C.TEST.RANDOM_BG_COLOR_RANGE = [[240,240],[240,240],[240,240]]
__C.TEST.VOXEL_THRESH = [.2,.3,.4,.5]
