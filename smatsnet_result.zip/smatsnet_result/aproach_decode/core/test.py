import numpy as np
import torch
import utils.helpers
from utils.amp import get_autocast

def test_net(cfg, epoch_idx, loader, writer, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn):
    autocast_cm = get_autocast()

    enc_shuf.eval(); enc_cnx.eval(); enc_vit.eval()
    ens.eval(); dec.eval(); mrg.eval(); rfn.eval()

    losses, ious = [], []
    bce = torch.nn.BCEWithLogitsLoss()  # stable logits loss [web:576]

    for _, (_, _, imgs, gt32) in enumerate(loader):
        imgs = utils.helpers.var_or_cuda(imgs)
        gt32 = utils.helpers.var_or_cuda(gt32)

        with torch.no_grad():
            with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
                f1 = enc_shuf(imgs)
                f2 = enc_cnx(imgs)
                f3 = enc_vit(imgs)
                fused2d = ens([f1, f2, f3])

                feat16, feat32, log16, log32 = dec(fused2d)
                fused16, fused32 = mrg(feat16, feat32, log16, log32)
                refined32 = rfn(fused32)

                loss = bce(refined32, gt32)
                losses.append(loss.item())

                prob = torch.sigmoid(refined32)
                sample_iou = []
                for th in cfg.TEST.VOXEL_THRESH:
                    vol = (prob >= th).float()
                    inter = torch.sum(vol * gt32).float()
                    union = torch.sum(torch.ge(vol + gt32, 1)).float()
                    sample_iou.append((inter / union).item())
                ious.append(max(sample_iou))

    mean_loss = float(np.mean(losses)) if losses else 0.0
    mean_iou = float(np.mean(ious)) if ious else 0.0

    if writer is not None:
        writer.add_scalar("Val/LossBCE", mean_loss, epoch_idx)
        writer.add_scalar("Val/IoU", mean_iou, epoch_idx)

    return mean_iou
