# -*- coding: utf-8 -*-
#
# Developed by Haozhe Xie <cshzxie@gmail.com>

import numpy as np
import torch
import matplotlib.pyplot as plt

from mpl_toolkits.mplot3d import Axes3D


def var_or_cuda(x):
    if torch.cuda.is_available():
        x = x.cuda(non_blocking=True)

    return x


def init_weights(m):
    if type(m) == torch.nn.Conv2d or type(m) == torch.nn.Conv3d or \
       type(m) == torch.nn.ConvTranspose2d or type(m) == torch.nn.ConvTranspose3d:
        torch.nn.init.kaiming_normal_(m.weight)
        if m.bias is not None:
            torch.nn.init.constant_(m.bias, 0)
    elif type(m) == torch.nn.BatchNorm2d or type(m) == torch.nn.BatchNorm3d:
        torch.nn.init.constant_(m.weight, 1)
        torch.nn.init.constant_(m.bias, 0)
    elif type(m) == torch.nn.Linear:
        torch.nn.init.normal_(m.weight, 0, 0.01)
        torch.nn.init.constant_(m.bias, 0)


def count_parameters(model):
    return sum(p.numel() for p in model.parameters())


def get_volume_views(volume):
    volume = volume.squeeze() >= 0.5  # Use logical operation directly
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')  # Create a 3D subplot directly
    ax.set_aspect('equal')
    ax.voxels(volume, edgecolor="k")

    # Draw the canvas so the renderer is not None
    # fig.canvas.draw()
    # #img = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
    # img = np.asarray(fig.canvas.buffer_rgba())

    # img = img.reshape(fig.canvas.get_width_height()[::-1] + (3,))
    # return img
    fig.canvas.draw()
    img = np.asarray(fig.canvas.buffer_rgba())      # (H, W, 4)
    img = img[:, :, :3].astype(np.uint8)            # (H, W, 3)
    plt.close(fig)
    return img


# # def get_volume_views(volume):
# #     # volume: numpy array, shape (1, D, H, W) or (D, H, W)
# #     volume = np.squeeze(volume) >= 0.5

# #     fig = plt.figure()
# #     ax = fig.add_subplot(111, projection='3d')
# #     ax.set_aspect('equal')
# #     ax.voxels(volume, edgecolor="k")

# #     fig.canvas.draw()
# #     # Get RGBA buffer as (H, W, 4)
# #     img = np.asarray(fig.canvas.buffer_rgba())
# #     # Drop alpha, keep RGB (H, W, 3) without reshape size mismatch
# #     img = img[:, :, :3]

# #     plt.close(fig)
# #     return img
# def get_volume_views(volume):
#     import matplotlib.pyplot as plt
#     import numpy as np

#     volume = np.squeeze(volume)
#     if volume.ndim != 3:
#         volume = volume.astype(bool)
#     volume = volume >= 0.5

#     fig = plt.figure(figsize=(6, 6))

#     ax = fig.add_subplot(111, projection='3d')
#     ax.set_aspect('equal')
#     ax.voxels(volume, edgecolor="k", alpha=0.5)
#     ax.set_xlim(0, volume.shape[0])
#     ax.set_ylim(0, volume.shape[1])
#     ax.set_zlim(0, volume.shape[2])


#     fig.canvas.draw()
#     # FIXED: np.asarray() first, then slice RGBA→RGB
#     img = np.asarray(fig.canvas.renderer.buffer_rgba())
#     img = img[:, :, :3]
#     img = img.astype(np.uint8)
#     img = np.asarray(fig.canvas.renderer.buffer_rgba())
#     img = img[:, :, :3]
#     img = img.astype(np.uint8)

#     plt.close(fig)
#     return img



