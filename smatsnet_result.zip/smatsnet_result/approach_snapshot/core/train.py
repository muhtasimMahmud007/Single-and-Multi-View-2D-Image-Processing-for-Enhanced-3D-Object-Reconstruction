import os
import logging
import torch
import torch.utils.data
import torch.nn.functional as F

import utils.data_loaders
import utils.data_transforms
import utils.helpers

from datetime import datetime as dt
from tensorboardX import SummaryWriter

from utils.amp import get_autocast, get_grad_scaler
from utils.losses import BCEDiceLoss
from core.test import test_net, test_snapshot_ensemble

from models.encoder import ShuffleNetEncoder, ConvNeXtEncoder, ViTTinyEncoder
from models.ensembler import RobustEnsembler
from models.decoder import Decoder
from models.merger import MultiScaleMerger
from models.refiner import Refiner


def train_net(cfg):
    IMG_SIZE = cfg.CONST.IMG_H, cfg.CONST.IMG_W
    CROP_SIZE = cfg.CONST.CROP_IMG_H, cfg.CONST.CROP_IMG_W

    train_tf = utils.data_transforms.Compose([
        utils.data_transforms.RandomCrop(IMG_SIZE, CROP_SIZE),
        utils.data_transforms.RandomBackground(cfg.TRAIN.RANDOM_BG_COLOR_RANGE),
        utils.data_transforms.ColorJitter(cfg.TRAIN.BRIGHTNESS, cfg.TRAIN.CONTRAST, cfg.TRAIN.SATURATION),
        utils.data_transforms.RandomNoise(cfg.TRAIN.NOISE_STD),
        utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
        utils.data_transforms.RandomFlip(),
        utils.data_transforms.RandomPermuteRGB(),
        utils.data_transforms.ToTensor(),
    ])

    val_tf = utils.data_transforms.Compose([
        utils.data_transforms.CenterCrop(IMG_SIZE, CROP_SIZE),
        utils.data_transforms.RandomBackground(cfg.TEST.RANDOM_BG_COLOR_RANGE),
        utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
        utils.data_transforms.ToTensor(),
    ])

    train_loader = torch.utils.data.DataLoader(
        dataset=utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TRAIN_DATASET](cfg).get_dataset(
            utils.data_loaders.DatasetType.TRAIN, cfg.CONST.N_VIEWS_RENDERING, train_tf),
        batch_size=cfg.CONST.BATCH_SIZE, num_workers=cfg.CONST.NUM_WORKER,
        pin_memory=True, shuffle=True, drop_last=True
    )

    val_loader = torch.utils.data.DataLoader(
        dataset=utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TEST_DATASET](cfg).get_dataset(
            utils.data_loaders.DatasetType.VAL, cfg.CONST.N_VIEWS_RENDERING, val_tf),
        batch_size=1, num_workers=cfg.CONST.NUM_WORKER,
        pin_memory=True, shuffle=False
    )

    enc_shuf = ShuffleNetEncoder(cfg, use_imagenet_weights=True)
    enc_cnx  = ConvNeXtEncoder(cfg, use_imagenet_weights=True)
    enc_vit  = ViTTinyEncoder(cfg, pretrained=True, model_name="vit_tiny_patch16_224")

    ens = RobustEnsembler(n_experts=3, c=256, vit_blocks=1, vit_heads=4, vit_mlp_ratio=2.0, dropout=0.1)
    dec = Decoder(cfg)
    mrg = MultiScaleMerger(cfg)
    rfn = Refiner(cfg)

    ens.apply(utils.helpers.init_weights)
    dec.apply(utils.helpers.init_weights)
    mrg.apply(utils.helpers.init_weights)
    rfn.apply(utils.helpers.init_weights)

    if torch.cuda.is_available():
        enc_shuf = torch.nn.DataParallel(enc_shuf).cuda()
        enc_cnx  = torch.nn.DataParallel(enc_cnx).cuda()
        enc_vit  = torch.nn.DataParallel(enc_vit).cuda()
        ens = torch.nn.DataParallel(ens).cuda()
        dec = torch.nn.DataParallel(dec).cuda()
        mrg = torch.nn.DataParallel(mrg).cuda()
        rfn = torch.nn.DataParallel(rfn).cuda()

    autocast_cm = get_autocast()
    scaler = get_grad_scaler()
    loss_fn = BCEDiceLoss(bce_weight=1.0, dice_weight=1.0, pos_weight=None)

    params = (
        list(enc_shuf.parameters()) + list(enc_cnx.parameters()) + list(enc_vit.parameters()) +
        list(ens.parameters()) + list(dec.parameters()) + list(mrg.parameters()) + list(rfn.parameters())
    )
    opt = torch.optim.Adam(params, lr=cfg.TRAIN.LEARNING_RATE, betas=cfg.TRAIN.BETAS, foreach=False)

    # Snapshot ensembling needs cosine cycles / restarts. [web:726][web:730]
    if cfg.TRAIN.USE_SNAPSHOT_ENSEMBLE:
        sch = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            opt,
            T_0=cfg.TRAIN.SNAPSHOT_T0_EPOCHS,
            T_mult=cfg.TRAIN.SNAPSHOT_TMULT,
            eta_min=cfg.TRAIN.SNAPSHOT_ETA_MIN
        )
        # for clean boundaries, recommended: NUM_EPOCHS = SNAPSHOT_M * SNAPSHOT_T0_EPOCHS [web:729]
    else:
        sch = torch.optim.lr_scheduler.MultiStepLR(opt, milestones=cfg.TRAIN.LR_MILESTONES, gamma=cfg.TRAIN.GAMMA)

    ts = dt.now().isoformat().replace(':', '-')
    out_dir = os.path.join(cfg.DIR.OUT_PATH, '%s', ts)
    cfg.DIR.LOGS = out_dir % 'logs'
    cfg.DIR.CHECKPOINTS = out_dir % 'checkpoints'
    os.makedirs(cfg.DIR.LOGS, exist_ok=True)
    os.makedirs(cfg.DIR.CHECKPOINTS, exist_ok=True)

    tr_w = SummaryWriter(os.path.join(cfg.DIR.LOGS, 'train'))
    te_w = SummaryWriter(os.path.join(cfg.DIR.LOGS, 'test'))

    best_iou = -1
    best_epoch = -1
    snapshot_idx = 0

    for epoch in range(cfg.TRAIN.NUM_EPOCHS):
        enc_shuf.train(); enc_cnx.train(); enc_vit.train()
        ens.train(); dec.train(); mrg.train(); rfn.train()

        for b, (_, _, imgs, gt32) in enumerate(train_loader):
            imgs = utils.helpers.var_or_cuda(imgs)
            gt32 = utils.helpers.var_or_cuda(gt32)
            gt16 = F.interpolate(gt32.unsqueeze(1), size=(16, 16, 16), mode="trilinear", align_corners=False).squeeze(1)

            opt.zero_grad(set_to_none=True)

            with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
                f1 = enc_shuf(imgs)
                f2 = enc_cnx(imgs)
                f3 = enc_vit(imgs)
                fused2d = ens([f1, f2, f3])

                feat16, feat32, log16, log32 = dec(fused2d)
                fused16, fused32 = mrg(feat16, feat32, log16, log32)

                loss_coarse16 = loss_fn(fused16, gt16)
                loss_coarse32 = loss_fn(fused32, gt32)

                refined32 = rfn(fused32)
                loss_refine = loss_fn(refined32, gt32)

                loss = 0.3 * loss_coarse16 + 1.0 * loss_coarse32 + 1.0 * loss_refine

            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()

            itr = epoch * len(train_loader) + b
            tr_w.add_scalar("Loss/Coarse16", loss_coarse16.item(), itr)
            tr_w.add_scalar("Loss/Coarse32", loss_coarse32.item(), itr)
            tr_w.add_scalar("Loss/Refine32", loss_refine.item(), itr)
            tr_w.add_scalar("Loss/Total", loss.item(), itr)

            if b % 20 == 0:
                logging.info("[E %d][B %d/%d] L16=%.4f L32=%.4f Lref=%.4f L=%.4f",
                             epoch + 1, b + 1, len(train_loader),
                             loss_coarse16.item(), loss_coarse32.item(), loss_refine.item(), loss.item())

        # Step scheduler once per epoch (simple & stable).
        # CosineAnnealingWarmRestarts supports epoch stepping. [web:730]
        sch.step(epoch + 1)

        # Log current LR
        lr_now = opt.param_groups[0]["lr"]
        tr_w.add_scalar("LR", lr_now, epoch + 1)

        # Validation IoU for this epoch
        iou = test_net(cfg, epoch + 1, val_loader, te_w, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn)

        # Save "best"
        is_best = iou > best_iou
        if is_best:
            best_iou = iou
            best_epoch = epoch

        # Save regular checkpoints as before
        if ((epoch + 1) % cfg.TRAIN.SAVE_FREQ == 0) or is_best:
            name = "checkpoint-best.pth" if is_best else f"checkpoint-epoch-{epoch+1:03d}.pth"
            path = os.path.join(cfg.DIR.CHECKPOINTS, name)
            torch.save({
                "epoch": epoch,
                "best_iou": best_iou,
                "best_epoch": best_epoch,
                "enc_shuf": enc_shuf.state_dict(),
                "enc_cnx": enc_cnx.state_dict(),
                "enc_vit": enc_vit.state_dict(),
                "ens": ens.state_dict(),
                "dec": dec.state_dict(),
                "mrg": mrg.state_dict(),
                "rfn": rfn.state_dict(),
                "opt": opt.state_dict(),
                "scaler": scaler.state_dict(),
                "sch": sch.state_dict(),
            }, path)
            logging.info("Saved: %s", path)

        # Save snapshot at the end of each cosine cycle
        if cfg.TRAIN.USE_SNAPSHOT_ENSEMBLE:
            # With T_mult=1, cycle ends every T0 epochs.
            # Save at epochs: T0, 2*T0, 3*T0, ... until M snapshots. [web:729][web:730]
            if ((epoch + 1) % cfg.TRAIN.SNAPSHOT_T0_EPOCHS == 0) and (snapshot_idx < cfg.TRAIN.SNAPSHOT_M):
                snapshot_idx += 1
                snap_name = f"snapshot-{snapshot_idx:02d}-epoch-{epoch+1:03d}.pth"
                snap_path = os.path.join(cfg.DIR.CHECKPOINTS, snap_name)
                torch.save({
                    "epoch": epoch,
                    "snapshot_idx": snapshot_idx,
                    "enc_shuf": enc_shuf.state_dict(),
                    "enc_cnx": enc_cnx.state_dict(),
                    "enc_vit": enc_vit.state_dict(),
                    "ens": ens.state_dict(),
                    "dec": dec.state_dict(),
                    "mrg": mrg.state_dict(),
                    "rfn": rfn.state_dict(),
                }, snap_path)
                logging.info("Saved snapshot: %s", snap_path)
                te_w.add_scalar("Snapshot/Index", snapshot_idx, epoch + 1)

                # Optional: evaluate snapshot ensemble as soon as we have >=2 snapshots
                if snapshot_idx >= 2 and cfg.TEST.USE_SNAPSHOT_ENSEMBLE:
                    ens_iou = test_snapshot_ensemble(cfg, epoch + 1, val_loader, te_w, cfg.DIR.CHECKPOINTS, snapshot_idx)
                    te_w.add_scalar("Val/IoU_SnapshotEnsemble", ens_iou, epoch + 1)

    tr_w.close()
    te_w.close()
# # import os
# # import logging
# # import torch
# # import torch.utils.data
# # import torch.nn.functional as F

# # import utils.data_loaders
# # import utils.data_transforms
# # import utils.helpers

# # from datetime import datetime as dt
# # from tensorboardX import SummaryWriter

# # from utils.amp import get_autocast, get_grad_scaler
# # from utils.losses import BCEDiceLoss
# # from core.test import test_net, test_snapshot_ensemble

# # from models.encoder import ShuffleNetEncoder, ConvNeXtEncoder, ViTTinyEncoder
# # from models.ensembler import RobustEnsembler
# # from models.decoder import Decoder
# # from models.merger import MultiScaleMerger
# # from models.refiner import Refiner


# # def train_net(cfg):
# #     IMG_SIZE = cfg.CONST.IMG_H, cfg.CONST.IMG_W
# #     CROP_SIZE = cfg.CONST.CROP_IMG_H, cfg.CONST.CROP_IMG_W

# #     train_tf = utils.data_transforms.Compose([
# #         utils.data_transforms.RandomCrop(IMG_SIZE, CROP_SIZE),
# #         utils.data_transforms.RandomBackground(cfg.TRAIN.RANDOM_BG_COLOR_RANGE),
# #         utils.data_transforms.ColorJitter(cfg.TRAIN.BRIGHTNESS, cfg.TRAIN.CONTRAST, cfg.TRAIN.SATURATION),
# #         utils.data_transforms.RandomNoise(cfg.TRAIN.NOISE_STD),
# #         utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
# #         utils.data_transforms.RandomFlip(),
# #         utils.data_transforms.RandomPermuteRGB(),
# #         utils.data_transforms.ToTensor(),
# #     ])

# #     val_tf = utils.data_transforms.Compose([
# #         utils.data_transforms.CenterCrop(IMG_SIZE, CROP_SIZE),
# #         utils.data_transforms.RandomBackground(cfg.TEST.RANDOM_BG_COLOR_RANGE),
# #         utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
# #         utils.data_transforms.ToTensor(),
# #     ])

# #     train_loader = torch.utils.data.DataLoader(
# #         dataset=utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TRAIN_DATASET](cfg).get_dataset(
# #             utils.data_loaders.DatasetType.TRAIN, cfg.CONST.N_VIEWS_RENDERING, train_tf),
# #         batch_size=cfg.CONST.BATCH_SIZE, num_workers=cfg.CONST.NUM_WORKER,
# #         pin_memory=True, shuffle=True, drop_last=True
# #     )

# #     val_loader = torch.utils.data.DataLoader(
# #         dataset=utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TEST_DATASET](cfg).get_dataset(
# #             utils.data_loaders.DatasetType.VAL, cfg.CONST.N_VIEWS_RENDERING, val_tf),
# #         batch_size=1, num_workers=cfg.CONST.NUM_WORKER,
# #         pin_memory=True, shuffle=False
# #     )

# #     enc_shuf = ShuffleNetEncoder(cfg, use_imagenet_weights=True)
# #     enc_cnx  = ConvNeXtEncoder(cfg, use_imagenet_weights=True)
# #     enc_vit  = ViTTinyEncoder(cfg, pretrained=True, model_name="vit_tiny_patch16_224")

# #     ens = RobustEnsembler(n_experts=3, c=256, vit_blocks=1, vit_heads=4, vit_mlp_ratio=2.0, dropout=0.1)
# #     dec = Decoder(cfg)
# #     mrg = MultiScaleMerger(cfg)
# #     rfn = Refiner(cfg)

# #     ens.apply(utils.helpers.init_weights)
# #     dec.apply(utils.helpers.init_weights)
# #     mrg.apply(utils.helpers.init_weights)
# #     rfn.apply(utils.helpers.init_weights)

# #     if torch.cuda.is_available():
# #         enc_shuf = torch.nn.DataParallel(enc_shuf).cuda()
# #         enc_cnx  = torch.nn.DataParallel(enc_cnx).cuda()
# #         enc_vit  = torch.nn.DataParallel(enc_vit).cuda()
# #         ens = torch.nn.DataParallel(ens).cuda()
# #         dec = torch.nn.DataParallel(dec).cuda()
# #         mrg = torch.nn.DataParallel(mrg).cuda()
# #         rfn = torch.nn.DataParallel(rfn).cuda()

# #     autocast_cm = get_autocast()
# #     scaler = get_grad_scaler()
# #     loss_fn = BCEDiceLoss(bce_weight=1.0, dice_weight=1.0, pos_weight=None)

# #     params = (
# #         list(enc_shuf.parameters()) + list(enc_cnx.parameters()) + list(enc_vit.parameters()) +
# #         list(ens.parameters()) + list(dec.parameters()) + list(mrg.parameters()) + list(rfn.parameters())
# #     )
# #     opt = torch.optim.Adam(params, lr=cfg.TRAIN.LEARNING_RATE, betas=cfg.TRAIN.BETAS, foreach=False)

# #     if cfg.TRAIN.USE_SNAPSHOT_ENSEMBLE:
# #         sch = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
# #             opt,
# #             T_0=cfg.TRAIN.SNAPSHOT_T0_EPOCHS,
# #             T_mult=cfg.TRAIN.SNAPSHOT_TMULT,
# #             eta_min=cfg.TRAIN.SNAPSHOT_ETA_MIN
# #         )
# #     else:
# #         sch = torch.optim.lr_scheduler.MultiStepLR(opt, milestones=cfg.TRAIN.LR_MILESTONES, gamma=cfg.TRAIN.GAMMA)

# #     # ---- Output dirs (important for resume) ----
# #     # If resuming, DO NOT create a new timestamp folder; keep the old run folder.
# #     if cfg.TRAIN.RESUME_TRAIN and hasattr(cfg.CONST, "WEIGHTS") and cfg.CONST.WEIGHTS:
# #         # assume weights live inside .../checkpoints/*.pth
# #         ckpt_dir = os.path.dirname(cfg.CONST.WEIGHTS)
# #         run_dir = os.path.dirname(ckpt_dir)
# #         cfg.DIR.CHECKPOINTS = ckpt_dir
# #         cfg.DIR.LOGS = os.path.join(run_dir, "logs")
# #         os.makedirs(cfg.DIR.LOGS, exist_ok=True)
# #         os.makedirs(cfg.DIR.CHECKPOINTS, exist_ok=True)
# #         logging.info("Resuming in run_dir=%s", run_dir)
# #     else:
# #         ts = dt.now().isoformat().replace(':', '-')
# #         out_dir = os.path.join(cfg.DIR.OUT_PATH, '%s', ts)
# #         cfg.DIR.LOGS = out_dir % 'logs'
# #         cfg.DIR.CHECKPOINTS = out_dir % 'checkpoints'
# #         os.makedirs(cfg.DIR.LOGS, exist_ok=True)
# #         os.makedirs(cfg.DIR.CHECKPOINTS, exist_ok=True)

# #     tr_w = SummaryWriter(os.path.join(cfg.DIR.LOGS, 'train'))
# #     te_w = SummaryWriter(os.path.join(cfg.DIR.LOGS, 'test'))

# #     # ---- Resume state ----
# #     start_epoch = 0
# #     best_iou = -1.0
# #     best_epoch = -1
# #     snapshot_idx = 0

# #     if cfg.TRAIN.RESUME_TRAIN and hasattr(cfg.CONST, "WEIGHTS") and cfg.CONST.WEIGHTS and os.path.exists(cfg.CONST.WEIGHTS):
# #         ckpt = torch.load(cfg.CONST.WEIGHTS, map_location="cuda" if torch.cuda.is_available() else "cpu")

# #         enc_shuf.load_state_dict(ckpt["enc_shuf"])
# #         enc_cnx.load_state_dict(ckpt["enc_cnx"])
# #         enc_vit.load_state_dict(ckpt["enc_vit"])
# #         ens.load_state_dict(ckpt["ens"])
# #         dec.load_state_dict(ckpt["dec"])
# #         mrg.load_state_dict(ckpt["mrg"])
# #         rfn.load_state_dict(ckpt["rfn"])

# #         if "opt" in ckpt:
# #             opt.load_state_dict(ckpt["opt"])
# #         if "scaler" in ckpt and ckpt["scaler"] is not None:
# #             scaler.load_state_dict(ckpt["scaler"])
# #         if "sch" in ckpt and ckpt["sch"] is not None:
# #             sch.load_state_dict(ckpt["sch"])  # scheduler supports load_state_dict [web:730]

# #         best_iou = float(ckpt.get("best_iou", best_iou))
# #         best_epoch = int(ckpt.get("best_epoch", best_epoch))

# #         # your checkpoint stores "epoch" as 0-based
# #         start_epoch = int(ckpt["epoch"]) + 1

# #         # recompute snapshot_idx from epoch boundary (safer than trusting ckpt)
# #         if cfg.TRAIN.USE_SNAPSHOT_ENSEMBLE:
# #             snapshot_idx = min(start_epoch // cfg.TRAIN.SNAPSHOT_T0_EPOCHS, cfg.TRAIN.SNAPSHOT_M)

# #         logging.info("Loaded weights=%s", cfg.CONST.WEIGHTS)
# #         logging.info("Resume start_epoch=%d best_iou=%.6f best_epoch=%d snapshot_idx=%d",
# #                      start_epoch, best_iou, best_epoch, snapshot_idx)

# #     # ---- Train loop ----
# #     for epoch in range(start_epoch, cfg.TRAIN.NUM_EPOCHS):
# #         enc_shuf.train(); enc_cnx.train(); enc_vit.train()
# #         ens.train(); dec.train(); mrg.train(); rfn.train()

# #         for b, (_, _, imgs, gt32) in enumerate(train_loader):
# #             imgs = utils.helpers.var_or_cuda(imgs)
# #             gt32 = utils.helpers.var_or_cuda(gt32)
# #             gt16 = F.interpolate(gt32.unsqueeze(1), size=(16, 16, 16), mode="trilinear", align_corners=False).squeeze(1)

# #             opt.zero_grad(set_to_none=True)

# #             with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
# #                 f1 = enc_shuf(imgs)
# #                 f2 = enc_cnx(imgs)
# #                 f3 = enc_vit(imgs)
# #                 fused2d = ens([f1, f2, f3])

# #                 feat16, feat32, log16, log32 = dec(fused2d)
# #                 fused16, fused32 = mrg(feat16, feat32, log16, log32)

# #                 loss_coarse16 = loss_fn(fused16, gt16)
# #                 loss_coarse32 = loss_fn(fused32, gt32)

# #                 refined32 = rfn(fused32)
# #                 loss_refine = loss_fn(refined32, gt32)

# #                 loss = 0.3 * loss_coarse16 + 1.0 * loss_coarse32 + 1.0 * loss_refine

# #             scaler.scale(loss).backward()
# #             scaler.step(opt)
# #             scaler.update()

# #             itr = epoch * len(train_loader) + b
# #             tr_w.add_scalar("Loss/Total", loss.item(), itr)

# #             if b % 20 == 0:
# #                 logging.info("[E %d][B %d/%d] L=%.4f", epoch + 1, b + 1, len(train_loader), loss.item())

# #         # Keep using epoch-based step with explicit epoch number. [web:730]
# #         sch.step(epoch + 1)

# #         lr_now = opt.param_groups[0]["lr"]
# #         tr_w.add_scalar("LR", lr_now, epoch + 1)

# #         iou = test_net(cfg, epoch + 1, val_loader, te_w, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn)

# #         is_best = iou > best_iou
# #         if is_best:
# #             best_iou = iou
# #             best_epoch = epoch

# #         if ((epoch + 1) % cfg.TRAIN.SAVE_FREQ == 0) or is_best:
# #             name = "checkpoint-best.pth" if is_best else f"checkpoint-epoch-{epoch+1:03d}.pth"
# #             path = os.path.join(cfg.DIR.CHECKPOINTS, name)
# #             torch.save({
# #                 "epoch": epoch,
# #                 "best_iou": best_iou,
# #                 "best_epoch": best_epoch,
# #                 "enc_shuf": enc_shuf.state_dict(),
# #                 "enc_cnx": enc_cnx.state_dict(),
# #                 "enc_vit": enc_vit.state_dict(),
# #                 "ens": ens.state_dict(),
# #                 "dec": dec.state_dict(),
# #                 "mrg": mrg.state_dict(),
# #                 "rfn": rfn.state_dict(),
# #                 "opt": opt.state_dict(),
# #                 "scaler": scaler.state_dict(),
# #                 "sch": sch.state_dict(),
# #             }, path)
# #             logging.info("Saved: %s", path)

# #         # Snapshot save at cycle end (40,80,120,160,200)
# #         if cfg.TRAIN.USE_SNAPSHOT_ENSEMBLE:
# #             if ((epoch + 1) % cfg.TRAIN.SNAPSHOT_T0_EPOCHS == 0) and (snapshot_idx < cfg.TRAIN.SNAPSHOT_M):
# #                 snapshot_idx += 1
# #                 snap_name = f"snapshot-{snapshot_idx:02d}-epoch-{epoch+1:03d}.pth"
# #                 snap_path = os.path.join(cfg.DIR.CHECKPOINTS, snap_name)
# #                 torch.save({
# #                     "epoch": epoch,
# #                     "snapshot_idx": snapshot_idx,
# #                     "enc_shuf": enc_shuf.state_dict(),
# #                     "enc_cnx": enc_cnx.state_dict(),
# #                     "enc_vit": enc_vit.state_dict(),
# #                     "ens": ens.state_dict(),
# #                     "dec": dec.state_dict(),
# #                     "mrg": mrg.state_dict(),
# #                     "rfn": rfn.state_dict(),
# #                 }, snap_path)
# #                 logging.info("Saved snapshot: %s", snap_path)

# #                 if snapshot_idx >= 2 and cfg.TEST.USE_SNAPSHOT_ENSEMBLE:
# #                     ens_iou = test_snapshot_ensemble(cfg, epoch + 1, val_loader, te_w, cfg.DIR.CHECKPOINTS, snapshot_idx)
# #                     te_w.add_scalar("Val/IoU_SnapshotEnsemble", ens_iou, epoch + 1)

# #     tr_w.close()
# #     te_w.close()
# import os
# import logging
# import torch
# import torch.utils.data
# import torch.nn.functional as F

# import utils.data_loaders
# import utils.data_transforms
# import utils.helpers

# from datetime import datetime as dt
# from tensorboardX import SummaryWriter

# from utils.amp import get_autocast, get_grad_scaler
# from utils.losses import BCEDiceLoss
# from core.test import test_net, test_snapshot_ensemble

# from models.encoder import ShuffleNetEncoder, ConvNeXtEncoder, ViTTinyEncoder
# from models.ensembler import RobustEnsembler
# from models.decoder import Decoder
# from models.merger import MultiScaleMerger
# from models.refiner import Refiner


# def _setup_file_logger(log_dir):
#     os.makedirs(log_dir, exist_ok=True)
#     log_path = os.path.join(log_dir, "console.log")

#     root = logging.getLogger()
#     root.setLevel(logging.INFO)

#     # Avoid duplicate handlers if you re-run in notebooks etc.
#     for h in list(root.handlers):
#         root.removeHandler(h)

#     fmt = logging.Formatter('[%(levelname)s] %(asctime)s %(message)s')

#     sh = logging.StreamHandler()
#     sh.setFormatter(fmt)
#     sh.setLevel(logging.INFO)

#     fh = logging.FileHandler(log_path, mode="a", encoding="utf-8")
#     fh.setFormatter(fmt)
#     fh.setLevel(logging.INFO)

#     root.addHandler(sh)
#     root.addHandler(fh)

#     logging.info("Logging to file: %s", log_path)


# def train_net(cfg):
#     IMG_SIZE = cfg.CONST.IMG_H, cfg.CONST.IMG_W
#     CROP_SIZE = cfg.CONST.CROP_IMG_H, cfg.CONST.CROP_IMG_W

#     train_tf = utils.data_transforms.Compose([
#         utils.data_transforms.RandomCrop(IMG_SIZE, CROP_SIZE),
#         utils.data_transforms.RandomBackground(cfg.TRAIN.RANDOM_BG_COLOR_RANGE),
#         utils.data_transforms.ColorJitter(cfg.TRAIN.BRIGHTNESS, cfg.TRAIN.CONTRAST, cfg.TRAIN.SATURATION),
#         utils.data_transforms.RandomNoise(cfg.TRAIN.NOISE_STD),
#         utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
#         utils.data_transforms.RandomFlip(),
#         utils.data_transforms.RandomPermuteRGB(),
#         utils.data_transforms.ToTensor(),
#     ])

#     val_tf = utils.data_transforms.Compose([
#         utils.data_transforms.CenterCrop(IMG_SIZE, CROP_SIZE),
#         utils.data_transforms.RandomBackground(cfg.TEST.RANDOM_BG_COLOR_RANGE),
#         utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
#         utils.data_transforms.ToTensor(),
#     ])

#     train_loader = torch.utils.data.DataLoader(
#         dataset=utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TRAIN_DATASET](cfg).get_dataset(
#             utils.data_loaders.DatasetType.TRAIN, cfg.CONST.N_VIEWS_RENDERING, train_tf),
#         batch_size=cfg.CONST.BATCH_SIZE, num_workers=cfg.CONST.NUM_WORKER,
#         pin_memory=True, shuffle=True, drop_last=True
#     )

#     val_loader = torch.utils.data.DataLoader(
#         dataset=utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TEST_DATASET](cfg).get_dataset(
#             utils.data_loaders.DatasetType.VAL, cfg.CONST.N_VIEWS_RENDERING, val_tf),
#         batch_size=1, num_workers=cfg.CONST.NUM_WORKER,
#         pin_memory=True, shuffle=False
#     )

#     enc_shuf = ShuffleNetEncoder(cfg, use_imagenet_weights=True)
#     enc_cnx  = ConvNeXtEncoder(cfg, use_imagenet_weights=True)
#     enc_vit  = ViTTinyEncoder(cfg, pretrained=True, model_name="vit_tiny_patch16_224")

#     ens = RobustEnsembler(n_experts=3, c=256, vit_blocks=1, vit_heads=4, vit_mlp_ratio=2.0, dropout=0.1)
#     dec = Decoder(cfg)
#     mrg = MultiScaleMerger(cfg)
#     rfn = Refiner(cfg)

#     ens.apply(utils.helpers.init_weights)
#     dec.apply(utils.helpers.init_weights)
#     mrg.apply(utils.helpers.init_weights)
#     rfn.apply(utils.helpers.init_weights)

#     if torch.cuda.is_available():
#         enc_shuf = torch.nn.DataParallel(enc_shuf).cuda()
#         enc_cnx  = torch.nn.DataParallel(enc_cnx).cuda()
#         enc_vit  = torch.nn.DataParallel(enc_vit).cuda()
#         ens = torch.nn.DataParallel(ens).cuda()
#         dec = torch.nn.DataParallel(dec).cuda()
#         mrg = torch.nn.DataParallel(mrg).cuda()
#         rfn = torch.nn.DataParallel(rfn).cuda()

#     autocast_cm = get_autocast()
#     scaler = get_grad_scaler()
#     loss_fn = BCEDiceLoss(bce_weight=1.0, dice_weight=1.0, pos_weight=None)

#     params = (
#         list(enc_shuf.parameters()) + list(enc_cnx.parameters()) + list(enc_vit.parameters()) +
#         list(ens.parameters()) + list(dec.parameters()) + list(mrg.parameters()) + list(rfn.parameters())
#     )
#     opt = torch.optim.Adam(params, lr=cfg.TRAIN.LEARNING_RATE, betas=cfg.TRAIN.BETAS, foreach=False)

#     if cfg.TRAIN.USE_SNAPSHOT_ENSEMBLE:
#         sch = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
#             opt,
#             T_0=cfg.TRAIN.SNAPSHOT_T0_EPOCHS,
#             T_mult=cfg.TRAIN.SNAPSHOT_TMULT,
#             eta_min=cfg.TRAIN.SNAPSHOT_ETA_MIN
#         )
#     else:
#         sch = torch.optim.lr_scheduler.MultiStepLR(opt, milestones=cfg.TRAIN.LR_MILESTONES, gamma=cfg.TRAIN.GAMMA)

#     # -----------------------
#     # Output directories
#     # -----------------------
#     if cfg.TRAIN.RESUME_TRAIN and cfg.CONST.WEIGHTS and os.path.exists(cfg.CONST.WEIGHTS):
#         ckpt_dir = os.path.dirname(cfg.CONST.WEIGHTS)          # .../checkpoints
#         run_dir = os.path.dirname(ckpt_dir)                    # .../<timestamp>
#         cfg.DIR.CHECKPOINTS = ckpt_dir
#         cfg.DIR.LOGS = os.path.join(run_dir, "logs")
#         os.makedirs(cfg.DIR.LOGS, exist_ok=True)
#         os.makedirs(cfg.DIR.CHECKPOINTS, exist_ok=True)
#     else:
#         ts = dt.now().isoformat().replace(':', '-')
#         out_dir = os.path.join(cfg.DIR.OUT_PATH, '%s', ts)
#         cfg.DIR.LOGS = out_dir % 'logs'
#         cfg.DIR.CHECKPOINTS = out_dir % 'checkpoints'
#         os.makedirs(cfg.DIR.LOGS, exist_ok=True)
#         os.makedirs(cfg.DIR.CHECKPOINTS, exist_ok=True)

#     _setup_file_logger(cfg.DIR.LOGS)
#     logging.info("LOG DIR: %s", cfg.DIR.LOGS)
#     logging.info("CKPT DIR: %s", cfg.DIR.CHECKPOINTS)

#     # TensorBoard writers (flush frequently so logs show even if crash) [web:969][web:965]
#     tr_w = SummaryWriter(os.path.join(cfg.DIR.LOGS, 'train'), flush_secs=10)
#     te_w = SummaryWriter(os.path.join(cfg.DIR.LOGS, 'test'), flush_secs=10)

#     # -----------------------
#     # Resume state
#     # -----------------------
#     start_epoch = 0
#     best_iou = -1.0
#     best_epoch = -1
#     snapshot_idx = 0

#     if cfg.TRAIN.RESUME_TRAIN and cfg.CONST.WEIGHTS and os.path.exists(cfg.CONST.WEIGHTS):
#         ckpt = torch.load(cfg.CONST.WEIGHTS, map_location="cuda" if torch.cuda.is_available() else "cpu")
#         enc_shuf.load_state_dict(ckpt["enc_shuf"])
#         enc_cnx.load_state_dict(ckpt["enc_cnx"])
#         enc_vit.load_state_dict(ckpt["enc_vit"])
#         ens.load_state_dict(ckpt["ens"])
#         dec.load_state_dict(ckpt["dec"])
#         mrg.load_state_dict(ckpt["mrg"])
#         rfn.load_state_dict(ckpt["rfn"])

#         if "opt" in ckpt:
#             opt.load_state_dict(ckpt["opt"])
#         if "scaler" in ckpt and ckpt["scaler"] is not None:
#             scaler.load_state_dict(ckpt["scaler"])
#         if "sch" in ckpt and ckpt["sch"] is not None:
#             sch.load_state_dict(ckpt["sch"])  # scheduler state restoration [web:730]

#         best_iou = float(ckpt.get("best_iou", best_iou))
#         best_epoch = int(ckpt.get("best_epoch", best_epoch))
#         start_epoch = int(ckpt["epoch"]) + 1

#         if cfg.TRAIN.USE_SNAPSHOT_ENSEMBLE:
#             snapshot_idx = min(start_epoch // cfg.TRAIN.SNAPSHOT_T0_EPOCHS, cfg.TRAIN.SNAPSHOT_M)

#         logging.info("Resumed from %s", cfg.CONST.WEIGHTS)
#         logging.info("start_epoch=%d best_iou=%.6f best_epoch=%d snapshot_idx=%d",
#                      start_epoch, best_iou, best_epoch, snapshot_idx)

#     # -----------------------
#     # Training loop
#     # -----------------------
#     for epoch in range(start_epoch, cfg.TRAIN.NUM_EPOCHS):
#         enc_shuf.train(); enc_cnx.train(); enc_vit.train()
#         ens.train(); dec.train(); mrg.train(); rfn.train()

#         for b, (_, _, imgs, gt32) in enumerate(train_loader):
#             imgs = utils.helpers.var_or_cuda(imgs)
#             gt32 = utils.helpers.var_or_cuda(gt32)
#             gt16 = F.interpolate(gt32.unsqueeze(1), size=(16, 16, 16), mode="trilinear", align_corners=False).squeeze(1)

#             opt.zero_grad(set_to_none=True)

#             with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
#                 f1 = enc_shuf(imgs)
#                 f2 = enc_cnx(imgs)
#                 f3 = enc_vit(imgs)
#                 fused2d = ens([f1, f2, f3])

#                 feat16, feat32, log16, log32 = dec(fused2d)
#                 fused16, fused32 = mrg(feat16, feat32, log16, log32)

#                 loss16 = loss_fn(fused16, gt16)
#                 loss32 = loss_fn(fused32, gt32)

#                 refined32 = rfn(fused32)
#                 lossref = loss_fn(refined32, gt32)

#                 loss = 0.3 * loss16 + 1.0 * loss32 + 1.0 * lossref

#             scaler.scale(loss).backward()
#             scaler.step(opt)
#             scaler.update()

#             itr = epoch * len(train_loader) + b
#             tr_w.add_scalar("Loss/Coarse16", loss16.item(), itr)
#             tr_w.add_scalar("Loss/Coarse32", loss32.item(), itr)
#             tr_w.add_scalar("Loss/Refine32", lossref.item(), itr)
#             tr_w.add_scalar("Loss/Total", loss.item(), itr)

#             if (b % cfg.TRAIN.LOG_FREQ) == 0:
#                 logging.info("[E %d/%d][B %d/%d] L16=%.4f L32=%.4f Lref=%.4f L=%.4f",
#                              epoch + 1, cfg.TRAIN.NUM_EPOCHS,
#                              b + 1, len(train_loader),
#                              loss16.item(), loss32.item(), lossref.item(), loss.item())

#         # epoch-level scheduler stepping (supports explicit epoch arg) [web:730]
#         sch.step(epoch + 1)
#         lr_now = opt.param_groups[0]["lr"]
#         tr_w.add_scalar("LR", lr_now, epoch + 1)

#         iou = test_net(cfg, epoch + 1, val_loader, te_w, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn)

#         is_best = iou > best_iou
#         if is_best:
#             best_iou = iou
#             best_epoch = epoch

#         if ((epoch + 1) % cfg.TRAIN.SAVE_FREQ == 0) or is_best:
#             name = "checkpoint-best.pth" if is_best else f"checkpoint-epoch-{epoch+1:03d}.pth"
#             path = os.path.join(cfg.DIR.CHECKPOINTS, name)
#             torch.save({
#                 "epoch": epoch,
#                 "best_iou": best_iou,
#                 "best_epoch": best_epoch,
#                 "enc_shuf": enc_shuf.state_dict(),
#                 "enc_cnx": enc_cnx.state_dict(),
#                 "enc_vit": enc_vit.state_dict(),
#                 "ens": ens.state_dict(),
#                 "dec": dec.state_dict(),
#                 "mrg": mrg.state_dict(),
#                 "rfn": rfn.state_dict(),
#                 "opt": opt.state_dict(),
#                 "scaler": scaler.state_dict(),
#                 "sch": sch.state_dict(),
#             }, path)
#             logging.info("Saved: %s", path)

#         # Snapshot at end of each 40-epoch cycle (40,80,120,160,200)
#         if cfg.TRAIN.USE_SNAPSHOT_ENSEMBLE:
#             if ((epoch + 1) % cfg.TRAIN.SNAPSHOT_T0_EPOCHS == 0) and (snapshot_idx < cfg.TRAIN.SNAPSHOT_M):
#                 snapshot_idx += 1
#                 snap_name = f"snapshot-{snapshot_idx:02d}-epoch-{epoch+1:03d}.pth"
#                 snap_path = os.path.join(cfg.DIR.CHECKPOINTS, snap_name)
#                 torch.save({
#                     "epoch": epoch,
#                     "snapshot_idx": snapshot_idx,
#                     "enc_shuf": enc_shuf.state_dict(),
#                     "enc_cnx": enc_cnx.state_dict(),
#                     "enc_vit": enc_vit.state_dict(),
#                     "ens": ens.state_dict(),
#                     "dec": dec.state_dict(),
#                     "mrg": mrg.state_dict(),
#                     "rfn": rfn.state_dict(),
#                 }, snap_path)
#                 logging.info("Saved snapshot: %s", snap_path)

#                 if snapshot_idx >= 2 and cfg.TEST.USE_SNAPSHOT_ENSEMBLE:
#                     ens_iou = test_snapshot_ensemble(cfg, epoch + 1, val_loader, te_w, cfg.DIR.CHECKPOINTS, snapshot_idx)
#                     te_w.add_scalar("Val/IoU_SnapshotEnsemble", ens_iou, epoch + 1)

#         # Force TB write every epoch (helps when runs crash) [web:965][web:969]
#         tr_w.flush()
#         te_w.flush()

#     tr_w.close()
#     te_w.close()
