# import os
# import glob
# import numpy as np
# import torch
# import utils.helpers
# from utils.amp import get_autocast


# def _forward_one(cfg, imgs, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn):
#     f1 = enc_shuf(imgs)
#     f2 = enc_cnx(imgs)
#     f3 = enc_vit(imgs)
#     fused2d = ens([f1, f2, f3])
#     feat16, feat32, log16, log32 = dec(fused2d)
#     fused16, fused32 = mrg(feat16, feat32, log16, log32)
#     refined32 = rfn(fused32)
#     return refined32  # logits [B,32,32,32]


# def test_net(cfg, epoch_idx, loader, writer, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn):
#     autocast_cm = get_autocast()

#     enc_shuf.eval(); enc_cnx.eval(); enc_vit.eval()
#     ens.eval(); dec.eval(); mrg.eval(); rfn.eval()

#     losses, ious = [], []
#     bce = torch.nn.BCEWithLogitsLoss()

#     for _, (_, _, imgs, gt32) in enumerate(loader):
#         imgs = utils.helpers.var_or_cuda(imgs)
#         gt32 = utils.helpers.var_or_cuda(gt32)

#         with torch.no_grad():
#             with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
#                 refined32 = _forward_one(cfg, imgs, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn)
#                 loss = bce(refined32, gt32)
#                 losses.append(loss.item())

#                 prob = torch.sigmoid(refined32)
#                 sample_iou = []
#                 for th in cfg.TEST.VOXEL_THRESH:
#                     vol = (prob >= th).float()
#                     inter = torch.sum(vol * gt32).float()
#                     union = torch.sum(torch.ge(vol + gt32, 1)).float()
#                     sample_iou.append((inter / union).item())
#                 ious.append(max(sample_iou))

#     mean_loss = float(np.mean(losses)) if losses else 0.0
#     mean_iou = float(np.mean(ious)) if ious else 0.0

#     if writer is not None:
#         writer.add_scalar("Val/LossBCE", mean_loss, epoch_idx)
#         writer.add_scalar("Val/IoU", mean_iou, epoch_idx)

#     return mean_iou


# def _load_snapshot_paths(checkpoints_dir, max_snapshots=None):
#     paths = sorted(glob.glob(os.path.join(checkpoints_dir, "snapshot-*-epoch-*.pth")))
#     if max_snapshots is not None:
#         paths = paths[:max_snapshots]
#     return paths


# def test_snapshot_ensemble(cfg, epoch_idx, loader, writer, checkpoints_dir, max_snapshots=None):
#     """
#     Evaluate snapshot ensemble by averaging logits from multiple saved snapshots. [web:726][web:729]
#     """
#     snap_paths = cfg.TEST.SNAPSHOT_PATHS if getattr(cfg.TEST, "SNAPSHOT_PATHS", None) else []
#     if not snap_paths:
#         snap_paths = _load_snapshot_paths(checkpoints_dir, max_snapshots=max_snapshots)

#     if len(snap_paths) == 0:
#         if writer is not None:
#             writer.add_scalar("Val/IoU_SnapshotEnsemble", 0.0, epoch_idx)
#         return 0.0

#     autocast_cm = get_autocast()

#     # Build fresh model instances (not DataParallel-wrapped copies from training)
#     from models.encoder import ShuffleNetEncoder, ConvNeXtEncoder, ViTTinyEncoder
#     from models.ensembler import RobustEnsembler
#     from models.decoder import Decoder
#     from models.merger import MultiScaleMerger
#     from models.refiner import Refiner

#     models_list = []

#     for p in snap_paths:
#         enc_shuf = ShuffleNetEncoder(cfg, use_imagenet_weights=False)
#         enc_cnx  = ConvNeXtEncoder(cfg, use_imagenet_weights=False)
#         enc_vit  = ViTTinyEncoder(cfg, pretrained=False, model_name="vit_tiny_patch16_224")
#         ens = RobustEnsembler(n_experts=3, c=256, vit_blocks=1, vit_heads=4, vit_mlp_ratio=2.0, dropout=0.1)
#         dec = Decoder(cfg)
#         mrg = MultiScaleMerger(cfg)
#         rfn = Refiner(cfg)

#         if torch.cuda.is_available():
#             enc_shuf = enc_shuf.cuda()
#             enc_cnx  = enc_cnx.cuda()
#             enc_vit  = enc_vit.cuda()
#             ens = ens.cuda()
#             dec = dec.cuda()
#             mrg = mrg.cuda()
#             rfn = rfn.cuda()

#         ckpt = torch.load(p, map_location="cuda" if torch.cuda.is_available() else "cpu")
#         enc_shuf.load_state_dict(ckpt["enc_shuf"])
#         enc_cnx.load_state_dict(ckpt["enc_cnx"])
#         enc_vit.load_state_dict(ckpt["enc_vit"])
#         ens.load_state_dict(ckpt["ens"])
#         dec.load_state_dict(ckpt["dec"])
#         mrg.load_state_dict(ckpt["mrg"])
#         rfn.load_state_dict(ckpt["rfn"])

#         enc_shuf.eval(); enc_cnx.eval(); enc_vit.eval()
#         ens.eval(); dec.eval(); mrg.eval(); rfn.eval()

#         models_list.append((enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn))

#     ious = []

#     for _, (_, _, imgs, gt32) in enumerate(loader):
#         imgs = utils.helpers.var_or_cuda(imgs)
#         gt32 = utils.helpers.var_or_cuda(gt32)

#         with torch.no_grad():
#             logits_sum = 0.0
#             with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
#                 for (enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn) in models_list:
#                     logits_sum = logits_sum + _forward_one(cfg, imgs, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn)

#             logits_avg = logits_sum / float(len(models_list))
#             prob = torch.sigmoid(logits_avg)

#             sample_iou = []
#             for th in cfg.TEST.VOXEL_THRESH:
#                 vol = (prob >= th).float()
#                 inter = torch.sum(vol * gt32).float()
#                 union = torch.sum(torch.ge(vol + gt32, 1)).float()
#                 sample_iou.append((inter / union).item())
#             ious.append(max(sample_iou))

#     mean_iou = float(np.mean(ious)) if ious else 0.0
#     if writer is not None:
#         writer.add_scalar("Val/IoU_SnapshotEnsemble", mean_iou, epoch_idx)

#     return mean_iou
import os
import glob
import numpy as np
import torch
import utils.helpers
from utils.amp import get_autocast


def _forward_one(cfg, imgs, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn):
    f1 = enc_shuf(imgs)
    f2 = enc_cnx(imgs)
    f3 = enc_vit(imgs)
    fused2d = ens([f1, f2, f3])
    feat16, feat32, log16, log32 = dec(fused2d)
    fused16, fused32 = mrg(feat16, feat32, log16, log32)
    refined32 = rfn(fused32)
    return refined32  # logits [B,32,32,32]


def test_net(cfg, epoch_idx, loader, writer, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn):
    autocast_cm = get_autocast()

    enc_shuf.eval(); enc_cnx.eval(); enc_vit.eval()
    ens.eval(); dec.eval(); mrg.eval(); rfn.eval()

    losses, ious = [], []
    bce = torch.nn.BCEWithLogitsLoss()

    for _, (_, _, imgs, gt32) in enumerate(loader):
        imgs = utils.helpers.var_or_cuda(imgs)
        gt32 = utils.helpers.var_or_cuda(gt32)

        with torch.no_grad():
            with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
                refined32 = _forward_one(cfg, imgs, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn)
                loss = bce(refined32, gt32)
                losses.append(loss.item())

                prob = torch.sigmoid(refined32)
                sample_iou = []
                for th in cfg.TEST.VOXEL_THRESH:
                    vol = (prob >= th).float()
                    inter = torch.sum(vol * gt32).float()
                    union = torch.sum(torch.ge(vol + gt32, 1)).float()
                    sample_iou.append((inter / union).item())
                ious.append(max(sample_iou))

    mean_loss = float(np.mean(losses)) if losses else 0.0
    mean_iou = float(np.mean(ious)) if ious else 0.0

    if writer is not None:
        writer.add_scalar("Val/LossBCE", mean_loss, epoch_idx)
        writer.add_scalar("Val/IoU", mean_iou, epoch_idx)

    return mean_iou


def _load_snapshot_paths(checkpoints_dir, max_snapshots=None):
    paths = sorted(glob.glob(os.path.join(checkpoints_dir, "snapshot-*-epoch-*.pth")))
    if max_snapshots is not None:
        paths = paths[:max_snapshots]
    return paths


def _strip_module_prefix(sd):
    """Remove leading 'module.' so DP checkpoints load into non-DP models. [web:81][web:91]"""
    return {k.replace("module.", "", 1): v for k, v in sd.items()}


def test_snapshot_ensemble(cfg, epoch_idx, loader, writer, checkpoints_dir, max_snapshots=None):
    """
    Evaluate snapshot ensemble by averaging logits from multiple saved snapshots.
    Snapshots were saved from DataParallel models, so 'module.' prefixes are stripped
    before loading into non-DataParallel instances. [web:79][web:82]
    """
    snap_paths = cfg.TEST.SNAPSHOT_PATHS if getattr(cfg.TEST, "SNAPSHOT_PATHS", None) else []
    if not snap_paths:
        snap_paths = _load_snapshot_paths(checkpoints_dir, max_snapshots=max_snapshots)

    if len(snap_paths) == 0:
        if writer is not None:
            writer.add_scalar("Val/IoU_SnapshotEnsemble", 0.0, epoch_idx)
        return 0.0

    autocast_cm = get_autocast()

    # Fresh (non-DataParallel) model instances
    from models.encoder import ShuffleNetEncoder, ConvNeXtEncoder, ViTTinyEncoder
    from models.ensembler import RobustEnsembler
    from models.decoder import Decoder
    from models.merger import MultiScaleMerger
    from models.refiner import Refiner

    models_list = []

    for p in snap_paths:
        enc_shuf = ShuffleNetEncoder(cfg, use_imagenet_weights=False)
        enc_cnx  = ConvNeXtEncoder(cfg, use_imagenet_weights=False)
        enc_vit  = ViTTinyEncoder(cfg, pretrained=False, model_name="vit_tiny_patch16_224")
        ens = RobustEnsembler(n_experts=3, c=256, vit_blocks=1, vit_heads=4, vit_mlp_ratio=2.0, dropout=0.1)
        dec = Decoder(cfg)
        mrg = MultiScaleMerger(cfg)
        rfn = Refiner(cfg)

        if torch.cuda.is_available():
            enc_shuf = enc_shuf.cuda()
            enc_cnx  = enc_cnx.cuda()
            enc_vit  = enc_vit.cuda()
            ens = ens.cuda()
            dec = dec.cuda()
            mrg = mrg.cuda()
            rfn = rfn.cuda()

        # Explicit weights_only=False keeps current behavior and quiets future default-flip warnings. [web:92][web:84]
        ckpt = torch.load(
            p,
            map_location="cuda" if torch.cuda.is_available() else "cpu",
            weights_only=False,
        )

        # Strip 'module.' prefixes coming from DataParallel
        ckpt["enc_shuf"] = _strip_module_prefix(ckpt["enc_shuf"])
        ckpt["enc_cnx"]  = _strip_module_prefix(ckpt["enc_cnx"])
        ckpt["enc_vit"]  = _strip_module_prefix(ckpt["enc_vit"])
        ckpt["ens"]      = _strip_module_prefix(ckpt["ens"])
        ckpt["dec"]      = _strip_module_prefix(ckpt["dec"])
        ckpt["mrg"]      = _strip_module_prefix(ckpt["mrg"])
        ckpt["rfn"]      = _strip_module_prefix(ckpt["rfn"])

        enc_shuf.load_state_dict(ckpt["enc_shuf"])
        enc_cnx.load_state_dict(ckpt["enc_cnx"])
        enc_vit.load_state_dict(ckpt["enc_vit"])
        ens.load_state_dict(ckpt["ens"])
        dec.load_state_dict(ckpt["dec"])
        mrg.load_state_dict(ckpt["mrg"])
        rfn.load_state_dict(ckpt["rfn"])

        enc_shuf.eval(); enc_cnx.eval(); enc_vit.eval()
        ens.eval(); dec.eval(); mrg.eval(); rfn.eval()

        models_list.append((enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn))

    ious = []

    for _, (_, _, imgs, gt32) in enumerate(loader):
        imgs = utils.helpers.var_or_cuda(imgs)
        gt32 = utils.helpers.var_or_cuda(gt32)

        with torch.no_grad():
            logits_sum = 0.0
            with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
                for (enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn) in models_list:
                    logits_sum = logits_sum + _forward_one(cfg, imgs, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn)

            logits_avg = logits_sum / float(len(models_list))
            prob = torch.sigmoid(logits_avg)

            sample_iou = []
            for th in cfg.TEST.VOXEL_THRESH:
                vol = (prob >= th).float()
                inter = torch.sum(vol * gt32).float()
                union = torch.sum(torch.ge(vol + gt32, 1)).float()
                sample_iou.append((inter / union).item())
            ious.append(max(sample_iou))

    mean_iou = float(np.mean(ious)) if ious else 0.0
    if writer is not None:
        writer.add_scalar("Val/IoU_SnapshotEnsemble", mean_iou, epoch_idx)

    return mean_iou
