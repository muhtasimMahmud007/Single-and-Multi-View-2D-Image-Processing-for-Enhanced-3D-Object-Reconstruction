import torch
import torch.nn as nn
import torch.nn.functional as F


class ResBlock3D(nn.Module):
    def __init__(self, c, leaky=0.0):
        super().__init__()
        act = nn.ReLU(inplace=True) if leaky <= 0 else nn.LeakyReLU(leaky, inplace=True)
        self.net = nn.Sequential(
            nn.Conv3d(c, c, 3, padding=1, bias=False),
            nn.BatchNorm3d(c),
            act,
            nn.Conv3d(c, c, 3, padding=1, bias=False),
            nn.BatchNorm3d(c),
        )
        self.act = act

    def forward(self, x):
        return self.act(x + self.net(x))


class UpBlock3D(nn.Module):
    def __init__(self, in_c, out_c, leaky=0.0, use_bias=False, n_res=2):
        super().__init__()
        act = nn.ReLU(inplace=True) if leaky <= 0 else nn.LeakyReLU(leaky, inplace=True)

        self.up = nn.Sequential(
            nn.ConvTranspose3d(in_c, out_c, kernel_size=4, stride=2, padding=1, bias=use_bias),
            nn.BatchNorm3d(out_c),
            act
        )
        self.res = nn.Sequential(*[ResBlock3D(out_c, leaky=leaky) for _ in range(n_res)])

    def forward(self, x):
        x = self.up(x)
        x = self.res(x)
        return x


class Decoder(nn.Module):
    """
    Stronger residual multi-scale decoder.
    Input per-view: [B,256,7,7]
    Output per-view stacks:
      feat16: [B,V,32,16,16,16]
      feat32: [B,V,8,32,32,32]
      log16:  [B,V,16,16,16]
      log32:  [B,V,32,32,32]
    """
    def __init__(self, cfg):
        super().__init__()
        leaky = float(getattr(cfg.NETWORK, "LEAKY_VALUE", 0.0))
        use_bias = bool(cfg.NETWORK.TCONV_USE_BIAS)
        act2d = nn.ReLU(inplace=True) if leaky <= 0 else nn.LeakyReLU(leaky, inplace=True)
        act3d = nn.ReLU(inplace=True) if leaky <= 0 else nn.LeakyReLU(leaky, inplace=True)

        # 2D refinement before lifting
        self.stem2d = nn.Sequential(
            nn.Conv2d(256, 256, 3, padding=1, bias=False),
            nn.BatchNorm2d(256),
            act2d,
            nn.Conv2d(256, 256, 3, padding=1, bias=False),
            nn.BatchNorm2d(256),
            act2d,
        )

        # Lift to 3D seed at 2^3
        self.seed_proj = nn.Sequential(
            nn.Conv3d(256, 128, 1, bias=False),
            nn.BatchNorm3d(128),
            act3d,
            ResBlock3D(128, leaky=leaky),
        )

        # Learned upsampling path: 2->4->8->16->32
        self.up4  = UpBlock3D(128, 128, leaky=leaky, use_bias=use_bias, n_res=2)  # 2->4
        self.up8  = UpBlock3D(128, 96,  leaky=leaky, use_bias=use_bias, n_res=2)  # 4->8
        self.up16 = UpBlock3D(96,  32,  leaky=leaky, use_bias=use_bias, n_res=2)  # 8->16
        self.up32 = UpBlock3D(32,  8,   leaky=leaky, use_bias=use_bias, n_res=2)  # 16->32

        # Logit heads
        self.head16 = nn.Conv3d(32, 1, 1, bias=True)
        self.head32 = nn.Conv3d(8,  1, 1, bias=True)

    def forward(self, image_features):
        # image_features: [B,V,256,7,7]
        x = image_features.permute(1, 0, 2, 3, 4).contiguous()  # [V,B,256,7,7]
        views = torch.split(x, 1, dim=0)

        feat16_list, feat32_list = [], []
        log16_list, log32_list = [], []

        for f in views:
            f = f.squeeze(0)          # [B,256,7,7]
            f = self.stem2d(f)

            # Make 2x2 and lift to 2^3
            f2 = F.interpolate(f, size=(2, 2), mode="bilinear", align_corners=False)   # [B,256,2,2]
            seed = f2.unsqueeze(-1).expand(-1, -1, -1, -1, 2)                          # [B,256,2,2,2]
            x2 = self.seed_proj(seed)                                                  # [B,128,2,2,2]

            x4  = self.up4(x2)                                                         # [B,128,4,4,4]
            x8  = self.up8(x4)                                                         # [B,96,8,8,8]
            feat16 = self.up16(x8)                                                     # [B,32,16,16,16]
            feat32 = self.up32(feat16)                                                 # [B,8,32,32,32]

            logits16 = self.head16(feat16).squeeze(1)                                  # [B,16,16,16]
            logits32 = self.head32(feat32).squeeze(1)                                  # [B,32,32,32]

            feat16_list.append(feat16)
            feat32_list.append(feat32)
            log16_list.append(logits16)
            log32_list.append(logits32)

        feat16 = torch.stack(feat16_list).permute(1, 0, 2, 3, 4, 5).contiguous()      # [B,V,32,16,16,16]
        feat32 = torch.stack(feat32_list).permute(1, 0, 2, 3, 4, 5).contiguous()      # [B,V,8,32,32,32]
        log16  = torch.stack(log16_list).permute(1, 0, 2, 3, 4).contiguous()          # [B,V,16,16,16]
        log32  = torch.stack(log32_list).permute(1, 0, 2, 3, 4).contiguous()          # [B,V,32,32,32]

        return feat16, feat32, log16, log32
