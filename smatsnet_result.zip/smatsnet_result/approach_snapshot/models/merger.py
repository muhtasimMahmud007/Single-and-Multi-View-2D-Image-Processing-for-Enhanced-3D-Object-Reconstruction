import torch
import torch.nn as nn
import torch.nn.functional as F

class MultiScaleMerger(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        leaky = cfg.NETWORK.LEAKY_VALUE

        self.score16 = nn.Sequential(
            nn.Conv3d(32, 16, 3, padding=1, bias=False),
            nn.BatchNorm3d(16),
            nn.LeakyReLU(leaky, inplace=True),
            nn.Conv3d(16, 1, 1, bias=True)
        )

        self.score32 = nn.Sequential(
            nn.Conv3d(8, 16, 3, padding=1, bias=False),
            nn.BatchNorm3d(16),
            nn.LeakyReLU(leaky, inplace=True),
            nn.Conv3d(16, 1, 1, bias=True)
        )

    def forward(self, feat16, feat32, log16, log32):
        B, V = log32.shape[:2]

        s32 = []
        for i in range(V):
            s32.append(self.score32(feat32[:, i]).squeeze(1))
        s32 = torch.stack(s32, dim=1)
        w32 = F.softmax(s32, dim=1)
        fused32 = torch.sum(w32 * log32, dim=1)

        s16 = []
        for i in range(V):
            s16.append(self.score16(feat16[:, i]).squeeze(1))
        s16 = torch.stack(s16, dim=1)
        w16 = F.softmax(s16, dim=1)
        fused16 = torch.sum(w16 * log16, dim=1)

        return fused16, fused32
