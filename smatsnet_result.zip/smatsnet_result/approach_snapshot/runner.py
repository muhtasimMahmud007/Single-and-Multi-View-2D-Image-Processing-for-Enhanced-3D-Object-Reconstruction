# #!/usr/bin/python3
# # -*- coding: utf-8 -*-
# import os
# os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

# import logging
# import matplotlib
# import numpy as np
# import sys
# matplotlib.use('Agg')

# from argparse import ArgumentParser
# from pprint import pprint

# from config import cfg
# from core.train import train_net
# from core.test import test_net


# def get_args_from_command_line():
#     parser = ArgumentParser(description='Runner (Lightweight Ensemble 3D Reconstruction)')
#     parser.add_argument('--gpu', dest='gpu_id', default=cfg.CONST.DEVICE, type=str)
#     parser.add_argument('--rand', dest='randomize', action='store_true')
#     parser.add_argument('--test', dest='test', action='store_true')
#     parser.add_argument('--batch-size', dest='batch_size', default=cfg.CONST.BATCH_SIZE, type=int)
#     parser.add_argument('--epoch', dest='epoch', default=cfg.TRAIN.NUM_EPOCHS, type=int)
#     parser.add_argument('--weights', dest='weights', default=None)
#     parser.add_argument('--out', dest='out_path', default=cfg.DIR.OUT_PATH)
#     return parser.parse_args()


# def main():
#     args = get_args_from_command_line()

#     if args.gpu_id is not None:
#         cfg.CONST.DEVICE = args.gpu_id
#     if not args.randomize:
#         np.random.seed(cfg.CONST.RNG_SEED)
#     if args.batch_size is not None:
#         cfg.CONST.BATCH_SIZE = args.batch_size
#     if args.epoch is not None:
#         cfg.TRAIN.NUM_EPOCHS = args.epoch
#     if args.out_path is not None:
#         cfg.DIR.OUT_PATH = args.out_path
#     if args.weights is not None:
#         cfg.CONST.WEIGHTS = args.weights
#         if not args.test:
#             cfg.TRAIN.RESUME_TRAIN = True

#     print('Use config:')
#     pprint(cfg)

#     if isinstance(cfg.CONST.DEVICE, str):
#         os.environ["CUDA_VISIBLE_DEVICES"] = cfg.CONST.DEVICE

#     if not args.test:
#         train_net(cfg)
#     else:
#         if 'WEIGHTS' in cfg.CONST and os.path.exists(cfg.CONST.WEIGHTS):
#             test_net(cfg)
#         else:
#             logging.error('Please pass --weights path/to/checkpoint.pth for testing.')
#             sys.exit(2)


# if __name__ == '__main__':
#     logging.basicConfig(format='[%(levelname)s] %(asctime)s %(message)s', level=logging.DEBUG)
#     main()



#!/usr/bin/python3
# -*- coding: utf-8 -*-
import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import sys
import logging
import numpy as np
import matplotlib
matplotlib.use("Agg")

from argparse import ArgumentParser
from pprint import pprint

from config import cfg
from core.train import train_net
from core.test import test_net


def get_args_from_command_line():
    parser = ArgumentParser(description='Runner (Snapshot Ensemble 3D Reconstruction)')
    parser.add_argument('--gpu', dest='gpu_id', default=cfg.CONST.DEVICE, type=str)
    parser.add_argument('--rand', dest='randomize', action='store_true')
    parser.add_argument('--test', dest='test', action='store_true')
    parser.add_argument('--batch-size', dest='batch_size', default=cfg.CONST.BATCH_SIZE, type=int)
    parser.add_argument('--epoch', dest='epoch', default=cfg.TRAIN.NUM_EPOCHS, type=int)
    parser.add_argument('--weights', dest='weights', default=None)
    parser.add_argument('--out', dest='out_path', default=cfg.DIR.OUT_PATH)
    return parser.parse_args()


def main():
    args = get_args_from_command_line()

    if args.gpu_id is not None:
        cfg.CONST.DEVICE = args.gpu_id
    if not args.randomize:
        np.random.seed(cfg.CONST.RNG_SEED)
    if args.batch_size is not None:
        cfg.CONST.BATCH_SIZE = args.batch_size
    if args.epoch is not None:
        cfg.TRAIN.NUM_EPOCHS = args.epoch
    if args.out_path is not None:
        cfg.DIR.OUT_PATH = args.out_path
    if args.weights is not None:
        cfg.CONST.WEIGHTS = args.weights
        if not args.test:
            cfg.TRAIN.RESUME_TRAIN = True

    if isinstance(cfg.CONST.DEVICE, str):
        os.environ["CUDA_VISIBLE_DEVICES"] = cfg.CONST.DEVICE

    print('Use config:')
    pprint(cfg)

    if not args.test:
        train_net(cfg)
    else:
        if cfg.CONST.WEIGHTS and os.path.exists(cfg.CONST.WEIGHTS):
            test_net(cfg)
        else:
            logging.error('Please pass --weights path/to/checkpoint.pth for testing.')
            sys.exit(2)


if __name__ == '__main__':
    # Configure console logging early
    logging.basicConfig(
        format='[%(levelname)s] %(asctime)s %(message)s',
        level=logging.INFO
    )
    main()