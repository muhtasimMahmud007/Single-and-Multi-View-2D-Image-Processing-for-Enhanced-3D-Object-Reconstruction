import numpy as np
import torch
import utils.helpers
from utils.amp import get_autocast


def test_net(cfg, epoch_idx, loader, writer, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn):
    autocast_cm = get_autocast()
    loss_fn = torch.nn.BCEWithLogitsLoss()

    enc_shuf.eval(); enc_cnx.eval(); enc_vit.eval()
    ens.eval(); dec.eval(); mrg.eval(); rfn.eval()

    losses, ious = [], []

    for _, (_, _, imgs, gt32) in enumerate(loader):
        imgs = utils.helpers.var_or_cuda(imgs)
        gt32 = utils.helpers.var_or_cuda(gt32)

        with torch.no_grad():
            with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
                f1 = enc_shuf(imgs)
                f2 = enc_cnx(imgs)
                f3 = enc_vit(imgs)

                fused = ens([f1, f2, f3])
                raw32, logits16, logits32 = dec(fused)
                fused16, fused32 = mrg(raw32, logits16, logits32)
                refined32 = rfn(fused32)

                loss = loss_fn(refined32, gt32)
                losses.append(loss.item())

                prob = torch.sigmoid(refined32)
                sample_iou = []
                for th in cfg.TEST.VOXEL_THRESH:
                    vol = (prob >= th).float()
                    inter = torch.sum(vol * gt32).float()
                    union = torch.sum(torch.ge(vol + gt32, 1)).float()
                    sample_iou.append((inter / union).item())
                ious.append(max(sample_iou))

    mean_loss = float(np.mean(losses)) if losses else 0.0
    mean_iou = float(np.mean(ious)) if ious else 0.0

    if writer is not None:
        writer.add_scalar("Val/Loss", mean_loss, epoch_idx)
        writer.add_scalar("Val/IoU", mean_iou, epoch_idx)

    return mean_iou
