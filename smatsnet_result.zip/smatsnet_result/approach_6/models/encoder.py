import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

from torchvision.models import (
    ShuffleNet_V2_X0_5_Weights,
    ConvNeXt_Tiny_Weights,
)

import timm  # ViT-tiny via timm forward_features() [page:1]


class _Adapter(nn.Module):
    def __init__(self, in_ch, out_ch=256):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x = F.adaptive_avg_pool2d(x, (7, 7))
        return self.proj(x)  # [B,256,7,7]


class ShuffleNetEncoder(nn.Module):
    def __init__(self, cfg, use_imagenet_weights=True):
        super().__init__()
        self.cfg = cfg
        w = ShuffleNet_V2_X0_5_Weights.DEFAULT if use_imagenet_weights else None
        net = models.shufflenet_v2_x0_5(weights=w)
        self.backbone = nn.Sequential(*list(net.children())[:-1])
        self.adapter = _Adapter(1024, 256)

    def forward(self, rendering_images):
        # rendering_images: [B,V,3,H,W]
        x = rendering_images.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(x, 1, dim=0)

        feats = []
        for img in views:
            f = self.backbone(img.squeeze(0))     # [B,1024,?,?]
            feats.append(self.adapter(f))         # [B,256,7,7]

        return torch.stack(feats).permute(1, 0, 2, 3, 4).contiguous()  # [B,V,256,7,7]


class ConvNeXtEncoder(nn.Module):
    def __init__(self, cfg, use_imagenet_weights=True):
        super().__init__()
        self.cfg = cfg
        w = ConvNeXt_Tiny_Weights.DEFAULT if use_imagenet_weights else None
        net = models.convnext_tiny(weights=w)
        self.backbone = net.features
        self.adapter = _Adapter(768, 256)

    def forward(self, rendering_images):
        x = rendering_images.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(x, 1, dim=0)

        feats = []
        for img in views:
            f = self.backbone(img.squeeze(0))     # [B,768,?,?]
            feats.append(self.adapter(f))         # [B,256,7,7]

        return torch.stack(feats).permute(1, 0, 2, 3, 4).contiguous()


class ViTTinyEncoder(nn.Module):
    """
    ViT-Tiny expert (timm):
    - create_model('vit_tiny_patch16_224', pretrained=True)
    - forward_features(img) gives unpooled last hidden state / tokens. [page:1]
    - patch tokens -> 14x14 map -> 7x7 -> adapt (C->256)
    """
    def __init__(self, cfg, pretrained=True, model_name="vit_tiny_patch16_224"):
        super().__init__()
        self.cfg = cfg
        self.vit = timm.create_model(model_name, pretrained=pretrained)  # [page:1]
        self.embed_dim = int(getattr(self.vit, "embed_dim", 192))
        self.adapter = _Adapter(self.embed_dim, 256)

    @staticmethod
    def _tokens_to_square_map(tokens):
        # tokens: [B,N,C], N usually 197 (CLS + 196 patches) at 224/16
        if tokens.dim() != 3:
            raise ValueError(f"Expected tokens [B,N,C], got {tuple(tokens.shape)}")

        if tokens.shape[1] == 197:
            patch = tokens[:, 1:, :]  # drop CLS
        else:
            patch = tokens

        B, L, C = patch.shape
        side = int(L ** 0.5)
        if side * side != L:
            raise ValueError(f"Patch token count {L} is not a square; cannot reshape to 2D grid.")
        return patch.transpose(1, 2).contiguous().view(B, C, side, side)  # [B,C,side,side]

    def forward(self, rendering_images):
        x = rendering_images.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(x, 1, dim=0)

        feats = []
        for img in views:
            img = img.squeeze(0)                         # [B,3,H,W]
            tokens = self.vit.forward_features(img)       # [B,N,C] for ViT-style. [page:1]
            fmap = self._tokens_to_square_map(tokens)     # [B,C,14,14]
            fmap = F.interpolate(fmap, size=(7, 7), mode="bilinear", align_corners=False)
            feats.append(self.adapter(fmap))              # [B,256,7,7]

        return torch.stack(feats).permute(1, 0, 2, 3, 4).contiguous()
