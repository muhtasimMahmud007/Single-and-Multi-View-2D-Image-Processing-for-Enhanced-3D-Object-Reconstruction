import torch

def get_autocast():
    if hasattr(torch, "autocast"):
        def autocast_cm(enabled=True, dtype=torch.float16):
            device_type = "cuda" if torch.cuda.is_available() else "cpu"
            return torch.autocast(device_type=device_type, enabled=enabled, dtype=dtype)
        return autocast_cm

    from torch.cuda.amp import autocast as cuda_autocast
    def autocast_cm(enabled=True, dtype=torch.float16):
        return cuda_autocast(enabled=enabled, dtype=dtype)
    return autocast_cm

def get_grad_scaler():
    if hasattr(torch, "amp") and hasattr(torch.amp, "GradScaler"):
        return torch.amp.GradScaler("cuda", enabled=torch.cuda.is_available())
    from torch.cuda.amp import GradScaler
    return GradScaler(enabled=torch.cuda.is_available())
