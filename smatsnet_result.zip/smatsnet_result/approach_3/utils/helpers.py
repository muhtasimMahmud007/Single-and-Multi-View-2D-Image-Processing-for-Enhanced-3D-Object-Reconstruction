# -*- coding: utf-8 -*-
# SMATNet++ Compatible Helpers (patched for bias=None safety)
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


def var_or_cuda(x):
    """Move tensor to CUDA if available"""
    if torch.cuda.is_available():
        x = x.cuda(non_blocking=True)
    return x


def init_weights(m):
    """
    Safe initialization:
    - Uses isinstance (handles subclasses)
    - Never touches bias/weight if it is None (fixes your crash) [web:299]
    """
    if isinstance(m, (nn.Conv2d, nn.Conv3d, nn.ConvTranspose2d, nn.ConvTranspose3d)):
        if getattr(m, "weight", None) is not None:
            nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
        if getattr(m, "bias", None) is not None:
            nn.init.constant_(m.bias, 0)

    elif isinstance(m, (nn.BatchNorm2d, nn.BatchNorm3d, nn.GroupNorm, nn.LayerNorm)):
        if getattr(m, "weight", None) is not None:
            nn.init.constant_(m.weight, 1)
        if getattr(m, "bias", None) is not None:
            nn.init.constant_(m.bias, 0)

    elif isinstance(m, nn.Linear):
        if getattr(m, "weight", None) is not None:
            nn.init.normal_(m.weight, 0, 0.01)
        if getattr(m, "bias", None) is not None:
            nn.init.constant_(m.bias, 0)


def count_parameters(model):
    """Count total trainable parameters"""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def get_volume_views(volume):
    """
    Convert 3D volume to RGB visualization for TensorBoard
    Input: [B, 1, 32, 32, 32] or [32, 32, 32] → Output: [H, W, 3] RGB
    """
    volume = np.squeeze(volume)
    volume = (volume >= 0.5).astype(bool)

    fig = plt.figure(figsize=(6, 6))
    ax = fig.add_subplot(111, projection='3d')
    ax.voxels(volume, facecolors='cyan', edgecolor='k', linewidth=0.1, alpha=0.7)
    ax.set_xlim(0, volume.shape[0])
    ax.set_ylim(0, volume.shape[1])
    ax.set_zlim(0, volume.shape[2])
    ax.set_axis_off()

    fig.canvas.draw()
    img_rgba = np.asarray(fig.canvas.buffer_rgba())
    img_rgb = img_rgba[:, :, :3].astype(np.uint8)
    plt.close(fig)
    return img_rgb
