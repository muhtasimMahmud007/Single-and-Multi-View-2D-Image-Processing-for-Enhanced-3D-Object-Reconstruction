import torch
import torch.nn as nn
import torch.nn.functional as F

class RobustEnsembler(nn.Module):
    """
    Option B ensemble:
    - MoE gating across K encoders (dynamic weights)
    - Cross-attention fusion between the strongest expert (query) and others (key/value)
    Output: [B,V,256,7,7]
    """
    def __init__(self, n_experts=3, c=256, heads=4, attn_dropout=0.1):
        super().__init__()
        self.n_experts = n_experts
        self.c = c
        self.heads = heads

        self.gate = nn.Sequential(
            nn.Linear(n_experts * c, 256),
            nn.ReLU(inplace=True),
            nn.Linear(256, n_experts)
        )

        self.q_proj = nn.Linear(c, c, bias=False)
        self.k_proj = nn.Linear(c, c, bias=False)
        self.v_proj = nn.Linear(c, c, bias=False)
        self.attn = nn.MultiheadAttention(embed_dim=c, num_heads=heads, dropout=attn_dropout, batch_first=True)

        self.out = nn.Sequential(
            nn.Conv2d(c, c, 3, padding=1, bias=False),
            nn.BatchNorm2d(c),
            nn.ReLU(inplace=True)
        )

    def forward(self, feats_list):
        # feats_list: list length K, each [B,V,C,7,7]
        K = len(feats_list)
        assert K == self.n_experts
        B, V, C, H, W = feats_list[0].shape

        # ----- MoE weights -----
        pooled = [f.mean(dim=(-1, -2)) for f in feats_list]         # K * [B,V,C]
        gate_in = torch.cat(pooled, dim=-1)                         # [B,V,K*C]
        w = F.softmax(self.gate(gate_in), dim=-1)                   # [B,V,K]

        # ----- weighted base fusion -----
        fused = 0.0
        for k in range(K):
            fused = fused + w[..., k].view(B, V, 1, 1, 1) * feats_list[k]  # [B,V,C,H,W]

        # ----- cross-attention refinement in token space -----
        # tokens: each view becomes sequence length L=H*W
        L = H * W
        fused_tokens = fused.view(B * V, C, L).transpose(1, 2)      # [B*V,L,C]

        # choose query expert = argmax gate weight per (B,V)
        topk = torch.argmax(w, dim=-1)                              # [B,V]
        topk = topk.reshape(B * V)

        # build Q from top expert tokens, K/V from fused tokens
        # (simple + stable: use fused as K/V, top-expert as Q)
        # gather top expert feature maps:
        experts = torch.stack(feats_list, dim=2)                    # [B,V,K,C,H,W]
        experts = experts.view(B * V, K, C, H, W)
        idx = topk.view(B * V, 1, 1, 1, 1).expand(-1, 1, C, H, W)   # not used directly for gather

        # manual gather
        q_maps = []
        for i in range(B * V):
            q_maps.append(experts[i, topk[i]])
        q_maps = torch.stack(q_maps, dim=0)                         # [B*V,C,H,W]
        q_tokens = q_maps.view(B * V, C, L).transpose(1, 2)         # [B*V,L,C]

        q = self.q_proj(q_tokens)
        k = self.k_proj(fused_tokens)
        v = self.v_proj(fused_tokens)

        attn_out, _ = self.attn(q, k, v)                            # [B*V,L,C]
        fused_tokens = fused_tokens + attn_out                      # residual

        fused = fused_tokens.transpose(1, 2).view(B * V, C, H, W)
        fused = self.out(fused).view(B, V, C, H, W)
        return fused
