import torch
import torch.nn as nn
import torch.nn.functional as F

class Decoder(nn.Module):
    """
    Input: fused features [B,V,256,7,7]
    Output:
      raw32      [B,V,9,32,32,32]   (context for merger)
      logits16   [B,V,16,16,16]     (coarse logits)
      logits32   [B,V,32,32,32]     (fine logits)
    """
    def __init__(self, cfg):
        super().__init__()
        use_bias = cfg.NETWORK.TCONV_USE_BIAS

        self.t1 = nn.Sequential(nn.ConvTranspose3d(256, 512, 4, 2, 1, bias=use_bias), nn.BatchNorm3d(512), nn.ReLU(True))
        self.t2 = nn.Sequential(nn.ConvTranspose3d(512, 128, 4, 2, 1, bias=use_bias), nn.BatchNorm3d(128), nn.ReLU(True))
        self.t3 = nn.Sequential(nn.ConvTranspose3d(128, 32, 4, 2, 1, bias=use_bias), nn.BatchNorm3d(32), nn.ReLU(True))   # -> 16^3
        self.t4 = nn.Sequential(nn.ConvTranspose3d(32, 8, 4, 2, 1, bias=use_bias), nn.BatchNorm3d(8), nn.ReLU(True))       # -> 32^3

        self.head16 = nn.Conv3d(32, 1, 1, bias=True)  # logits at 16^3
        self.head32 = nn.Conv3d(8, 1, 1, bias=True)   # logits at 32^3

    def forward(self, image_features):
        # iterate views
        x = image_features.permute(1, 0, 2, 3, 4).contiguous()  # [V,B,C,H,W]
        views = torch.split(x, 1, dim=0)

        raw32_list, l16_list, l32_list = [], [], []

        for f in views:
            f = f.squeeze(0)  # [B,256,7,7]
            f2 = F.interpolate(f, size=(2, 2), mode="bilinear", align_corners=False)
            v = f2.unsqueeze(-1).expand(-1, -1, -1, -1, 2)      # [B,256,2,2,2]

            v = self.t1(v)   # 4^3
            v = self.t2(v)   # 8^3
            v16 = self.t3(v) # [B,32,16,16,16]
            logits16 = self.head16(v16).squeeze(1)  # [B,16,16,16]

            v32 = self.t4(v16)                      # [B,8,32,32,32]
            logits32 = self.head32(v32).squeeze(1)  # [B,32,32,32]

            raw32 = torch.cat([v32, self.head32(v32)], dim=1)   # [B,9,32,32,32]
            raw32_list.append(raw32)
            l16_list.append(logits16)
            l32_list.append(logits32)

        raw32 = torch.stack(raw32_list).permute(1, 0, 2, 3, 4, 5).contiguous()  # [B,V,9,32,32,32]
        l16 = torch.stack(l16_list).permute(1, 0, 2, 3, 4).contiguous()         # [B,V,16,16,16]
        l32 = torch.stack(l32_list).permute(1, 0, 2, 3, 4).contiguous()         # [B,V,32,32,32]
        return raw32, l16, l32
