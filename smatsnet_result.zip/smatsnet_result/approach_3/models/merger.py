import torch
import torch.nn as nn
import torch.nn.functional as F

class CrossAttentionMerger(nn.Module):
    """
    Inputs:
      raw32:    [B,V,9,32,32,32]
      logits16: [B,V,16,16,16]
      logits32: [B,V,32,32,32]
    Outputs:
      fused16:  [B,16,16,16]
      fused32:  [B,32,32,32]
    """
    def __init__(self, cfg, heads=4, dropout=0.1):
        super().__init__()
        leaky = cfg.NETWORK.LEAKY_VALUE

        # Context-aware per-voxel score (per view)
        self.score_net = nn.Sequential(
            nn.Conv3d(9, 16, 3, padding=1, bias=False),
            nn.BatchNorm3d(16),
            nn.LeakyReLU(leaky, inplace=True),
            nn.Conv3d(16, 1, 1, bias=True)
        )

        # View-attention over V views (global weights per view)
        # token dim = 32 (small), so attention is cheap
        self.view_attn = nn.MultiheadAttention(embed_dim=32, num_heads=heads, dropout=dropout, batch_first=True)
        self.view_proj = nn.Linear(32, 1)

    def forward(self, raw32, logits16, logits32):
        B, V = logits32.shape[:2]

        # -----------------------------
        # (A) Context-aware voxel weights
        # -----------------------------
        score_list = []
        for i in range(V):
            s = self.score_net(raw32[:, i])      # [B,1,32,32,32]
            score_list.append(s.squeeze(1))      # [B,32,32,32]
        scores = torch.stack(score_list, dim=1)  # [B,V,32,32,32]
        w_voxel32 = F.softmax(scores, dim=1)     # across views

        fused32_ctx = torch.sum(w_voxel32 * logits32, dim=1)  # [B,32,32,32]

        w_voxel16 = F.interpolate(w_voxel32, size=(16, 16, 16), mode="trilinear", align_corners=False)
        fused16_ctx = torch.sum(w_voxel16 * logits16, dim=1)  # [B,16,16,16]

        # -----------------------------
        # (B) Cross-attention view weights (global per-view)
        # -----------------------------
        # Build view tokens: [B,V,32]
        # Use simple statistics from logits32; stable and cheap.
        m = logits32.mean(dim=(2, 3, 4))          # [B,V]
        s = logits32.std(dim=(2, 3, 4))           # [B,V]
        a = logits32.abs().mean(dim=(2, 3, 4))    # [B,V]
        tok = torch.stack([m, s, a, m * a], dim=-1)  # [B,V,4]
        tok = F.pad(tok, (0, 28), value=0.0)         # [B,V,32]

        attn_out, _ = self.view_attn(tok, tok, tok)      # [B,V,32]
        attn_logits = self.view_proj(attn_out).squeeze(-1)  # [B,V]
        w_view = F.softmax(attn_logits, dim=1)              # [B,V]

        # IMPORTANT: reshape to broadcast with logits volumes
        w_view32 = w_view.view(B, V, 1, 1, 1)               # [B,V,1,1,1]
        fused32_attn = torch.sum(w_view32 * logits32, dim=1)  # [B,32,32,32]

        w_view16 = w_view32
        w_view16 = F.interpolate(w_view16, size=(16, 16, 16), mode="trilinear", align_corners=False)  # [B,V,16,16,16]
        fused16_attn = torch.sum(w_view16 * logits16, dim=1)  # [B,16,16,16]

        # -----------------------------
        # Final fusion (Option B)
        # -----------------------------
        fused32 = 0.7 * fused32_ctx + 0.3 * fused32_attn
        fused16 = 0.7 * fused16_ctx + 0.3 * fused16_attn
        return fused16, fused32
