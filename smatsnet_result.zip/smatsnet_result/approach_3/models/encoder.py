import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

from torchvision.models import (
    ShuffleNet_V2_X0_5_Weights,
    ShuffleNet_V2_X1_0_Weights,
    MobileNet_V3_Large_Weights,
    EfficientNet_B0_Weights,
)

class _Adapter(nn.Module):
    def __init__(self, in_ch, out_ch=256):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x = F.adaptive_avg_pool2d(x, (7, 7))
        return self.proj(x)

class ShuffleNetEncoder(nn.Module):
    def __init__(self, cfg, variant="x0_5", use_imagenet_weights=True):
        super().__init__()
        self.cfg = cfg

        if variant == "x0_5":
            w = ShuffleNet_V2_X0_5_Weights.DEFAULT if use_imagenet_weights else None
            net = models.shufflenet_v2_x0_5(weights=w)
        else:
            w = ShuffleNet_V2_X1_0_Weights.DEFAULT if use_imagenet_weights else None
            net = models.shufflenet_v2_x1_0(weights=w)

        self.backbone = nn.Sequential(*list(net.children())[:-1])
        self.adapter = _Adapter(1024, 256)

    def forward(self, rendering_images):
        x = rendering_images.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(x, 1, dim=0)
        feats = []
        for img in views:
            f = self.backbone(img.squeeze(0))
            feats.append(self.adapter(f))
        return torch.stack(feats).permute(1, 0, 2, 3, 4).contiguous()

class MobileNetV3Encoder(nn.Module):
    def __init__(self, cfg, use_imagenet_weights=True):
        super().__init__()
        self.cfg = cfg
        w = MobileNet_V3_Large_Weights.DEFAULT if use_imagenet_weights else None
        net = models.mobilenet_v3_large(weights=w)
        self.backbone = net.features
        self.adapter = _Adapter(960, 256)

    def forward(self, rendering_images):
        x = rendering_images.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(x, 1, dim=0)
        feats = []
        for img in views:
            f = self.backbone(img.squeeze(0))
            feats.append(self.adapter(f))
        return torch.stack(feats).permute(1, 0, 2, 3, 4).contiguous()

class EfficientNetB0Encoder(nn.Module):
    def __init__(self, cfg, use_imagenet_weights=True):
        super().__init__()
        self.cfg = cfg
        w = EfficientNet_B0_Weights.DEFAULT if use_imagenet_weights else None
        net = models.efficientnet_b0(weights=w)
        self.backbone = net.features
        self.adapter = _Adapter(1280, 256)

    def forward(self, rendering_images):
        x = rendering_images.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(x, 1, dim=0)
        feats = []
        for img in views:
            f = self.backbone(img.squeeze(0))
            feats.append(self.adapter(f))
        return torch.stack(feats).permute(1, 0, 2, 3, 4).contiguous()
