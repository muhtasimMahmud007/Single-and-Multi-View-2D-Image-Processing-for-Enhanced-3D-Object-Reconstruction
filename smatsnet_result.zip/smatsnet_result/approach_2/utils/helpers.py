# -*- coding: utf-8 -*-
# SMATNet++ Compatible Helpers
import numpy as np
import torch
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def var_or_cuda(x):
    """Move tensor to CUDA if available"""
    if torch.cuda.is_available():
        x = x.cuda(non_blocking=True)
    return x

def init_weights(m):
    """Kaiming initialization for conv layers, proper init for BN/Linear"""
    if type(m) == torch.nn.Conv2d or type(m) == torch.nn.Conv3d or \
       type(m) == torch.nn.ConvTranspose2d or type(m) == torch.nn.ConvTranspose3d:
        torch.nn.init.kaiming_normal_(m.weight)
        if m.bias is not None:
            torch.nn.init.constant_(m.bias, 0)
    elif type(m) == torch.nn.BatchNorm2d or type(m) == torch.nn.BatchNorm3d:
        torch.nn.init.constant_(m.weight, 1)
        torch.nn.init.constant_(m.bias, 0)
    elif type(m) == torch.nn.Linear:
        torch.nn.init.normal_(m.weight, 0, 0.01)
        torch.nn.init.constant_(m.bias, 0)

def count_parameters(model):
    """Count total trainable parameters"""
    return sum(p.numel() for p in model.parameters())

def get_volume_views(volume):
    """
    Convert 3D volume to RGB visualization for TensorBoard
    Input: [B, 1, 32, 32, 32] or [32, 32, 32] → Output: [H, W, 3] RGB
    """
    # Handle batched/single volumes
    volume = np.squeeze(volume)  # Remove batch/dim=1 dims
    volume = (volume >= 0.5).astype(bool)  # Binarize
    
    # Create 3D voxel plot
    fig = plt.figure(figsize=(6, 6))
    ax = fig.add_subplot(111, projection='3d')
    ax.voxels(volume, facecolors='cyan', edgecolor='k', linewidth=0.1, alpha=0.7)
    ax.set_xlim(0, volume.shape[0])
    ax.set_ylim(0, volume.shape[1])
    ax.set_zlim(0, volume.shape[2])
    ax.set_axis_off()
    
    # Render and extract RGB
    fig.canvas.draw()
    img_rgba = np.asarray(fig.canvas.buffer_rgba())  # [H, W, 4]
    img_rgb = img_rgba[:, :, :3].astype(np.uint8)    # [H, W, 3] RGB
    
    plt.close(fig)
    return img_rgb
