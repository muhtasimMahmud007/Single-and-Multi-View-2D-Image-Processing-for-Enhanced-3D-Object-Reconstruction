# utils/amp.py
import torch

def get_autocast():
    """
    Returns a context manager factory `autocast_cm()` that works for:
    - old API: torch.cuda.amp.autocast(enabled=..., dtype=...)
    - new API: torch.autocast(device_type="cuda", enabled=..., dtype=...)

    Usage:
        autocast_cm = get_autocast()
        with autocast_cm():
            ...
    """
    # Prefer unified torch.autocast if available
    if hasattr(torch, "autocast"):
        def autocast_cm(enabled=True, dtype=torch.float16):
            device_type = "cuda" if torch.cuda.is_available() else "cpu"
            return torch.autocast(device_type=device_type, enabled=enabled, dtype=dtype)
        return autocast_cm

    # Fallback: CUDA-only autocast
    from torch.cuda.amp import autocast as cuda_autocast
    def autocast_cm(enabled=True, dtype=torch.float16):
        return cuda_autocast(enabled=enabled, dtype=dtype)
    return autocast_cm


def get_grad_scaler():
    """
    Returns a GradScaler that works for:
    - new API: torch.amp.GradScaler("cuda")
    - old API: torch.cuda.amp.GradScaler()
    """
    if hasattr(torch, "amp") and hasattr(torch.amp, "GradScaler"):
        # Newer API
        return torch.amp.GradScaler("cuda", enabled=torch.cuda.is_available())
    # Older API
    from torch.cuda.amp import GradScaler
    return GradScaler(enabled=torch.cuda.is_available())
