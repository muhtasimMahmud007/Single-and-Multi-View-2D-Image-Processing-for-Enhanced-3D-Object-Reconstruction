# models/feature_extractor.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

# NOTE:
# - We always end with AdaptiveAvgPool2d((7,7)) then a 1x1 conv to 256 channels
# - This makes all backbones compatible for ensembling + decoder

class _BackboneAdapter(nn.Module):
    def __init__(self, out_ch, proj_ch=256):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Conv2d(out_ch, proj_ch, kernel_size=1, bias=False),
            nn.BatchNorm2d(proj_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x = F.adaptive_avg_pool2d(x, (7, 7))
        x = self.proj(x)
        return x  # [B,256,7,7]


class ShuffleNetEncoder(nn.Module):
    """
    Lighter than ResNet50. Keep ShuffleNet, but use x0.5 or x1.0.
    torchvision provides shufflenet_v2_x0_5 / x1_0. [web:275]
    """
    def __init__(self, cfg, variant="x0_5", pretrained=True):
        super().__init__()
        self.cfg = cfg

        if variant == "x0_5":
            net = models.shufflenet_v2_x0_5(pretrained=pretrained)
            out_ch = 1024  # final conv channels (ShuffleNet v2 family)
        else:
            net = models.shufflenet_v2_x1_0(pretrained=pretrained)
            out_ch = 1024

        # children()[:-1] keeps features up to last conv stage, drops classifier
        self.backbone = nn.Sequential(*list(net.children())[:-1])
        self.adapter = _BackboneAdapter(out_ch, 256)

    def forward(self, rendering_images):
        rendering_images = rendering_images.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(rendering_images, 1, dim=0)

        feats = []
        for img in views:
            x = self.backbone(img.squeeze(0))      # ~[B,1024,7,7]
            x = self.adapter(x)                    # [B,256,7,7]
            feats.append(x)

        return torch.stack(feats).permute(1, 0, 2, 3, 4).contiguous()


class MobileNetV3Encoder(nn.Module):
    """
    MobileNetV3-Large backbone from torchvision. [web:277]
    """
    def __init__(self, cfg, pretrained=True):
        super().__init__()
        self.cfg = cfg
        net = models.mobilenet_v3_large(pretrained=pretrained)

        # net.features outputs feature map (usually 960 channels at last stage)
        self.backbone = net.features
        out_ch = 960
        self.adapter = _BackboneAdapter(out_ch, 256)

    def forward(self, rendering_images):
        rendering_images = rendering_images.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(rendering_images, 1, dim=0)

        feats = []
        for img in views:
            x = self.backbone(img.squeeze(0))  # [B,960,H,W] (often 7x7 for 224 input)
            x = self.adapter(x)                # [B,256,7,7]
            feats.append(x)

        return torch.stack(feats).permute(1, 0, 2, 3, 4).contiguous()


class EfficientNetB0Encoder(nn.Module):
    """
    EfficientNet-B0 from torchvision. last_channel=1280 in torchvision impl. [web:276]
    """
    def __init__(self, cfg, pretrained=True):
        super().__init__()
        self.cfg = cfg
        net = models.efficientnet_b0(pretrained=pretrained)

        # net.features returns conv feature map, final stage has 1280 channels in torchvision [web:276]
        self.backbone = net.features
        out_ch = 1280
        self.adapter = _BackboneAdapter(out_ch, 256)

    def forward(self, rendering_images):
        rendering_images = rendering_images.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(rendering_images, 1, dim=0)

        feats = []
        for img in views:
            x = self.backbone(img.squeeze(0))  # [B,1280,H,W]
            x = self.adapter(x)                # [B,256,7,7]
            feats.append(x)

        return torch.stack(feats).permute(1, 0, 2, 3, 4).contiguous()
