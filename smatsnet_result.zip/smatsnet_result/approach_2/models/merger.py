# models/merger.py
import torch
import torch.nn as nn
import torch.nn.functional as F

class Merger(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        leaky = cfg.NETWORK.LEAKY_VALUE

        self.layer1 = nn.Sequential(nn.Conv3d(9, 9, 3, padding=1), nn.BatchNorm3d(9), nn.LeakyReLU(leaky, inplace=True))
        self.layer2 = nn.Sequential(nn.Conv3d(9, 9, 3, padding=1), nn.BatchNorm3d(9), nn.LeakyReLU(leaky, inplace=True))
        self.layer3 = nn.Sequential(nn.Conv3d(9, 9, 3, padding=1), nn.BatchNorm3d(9), nn.LeakyReLU(leaky, inplace=True))
        self.layer4 = nn.Sequential(nn.Conv3d(9, 9, 3, padding=1), nn.BatchNorm3d(9), nn.LeakyReLU(leaky, inplace=True))
        self.layer5 = nn.Sequential(nn.Conv3d(36, 9, 3, padding=1), nn.BatchNorm3d(9), nn.LeakyReLU(leaky, inplace=True))
        self.layer6 = nn.Sequential(nn.Conv3d(9, 1, 3, padding=1), nn.BatchNorm3d(1), nn.LeakyReLU(leaky, inplace=True))

    def forward(self, raw_features, logits_volumes):
        # logits_volumes: [B,V,32,32,32] (LOGITS)
        V = logits_volumes.size(1)
        raw_split = torch.split(raw_features, 1, dim=1)

        weights = []
        for i in range(V):
            raw = raw_split[i].squeeze(1)  # [B,9,32,32,32]
            w1 = self.layer1(raw)
            w2 = self.layer2(w1)
            w3 = self.layer3(w2)
            w4 = self.layer4(w3)
            w = self.layer5(torch.cat([w1, w2, w3, w4], dim=1))
            w = self.layer6(w).squeeze(1)  # [B,32,32,32]
            weights.append(w)

        weights = torch.stack(weights).permute(1, 0, 2, 3, 4).contiguous()  # [B,V,32,32,32]
        weights = F.softmax(weights, dim=1)

        fused_logits = torch.sum(logits_volumes * weights, dim=1)  # [B,32,32,32]
        return fused_logits
