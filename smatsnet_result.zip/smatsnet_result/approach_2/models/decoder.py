# models/decoder.py
import torch
import torch.nn as nn
import torch.nn.functional as F

class Decoder(nn.Module):
    """
    Input:  image_features [B,V,256,7,7]
    Output:
      raw_features [B,V,9,32,32,32]
      gen_logits   [B,V,32,32,32]   (LOGITS)
    """
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        use_bias = cfg.NETWORK.TCONV_USE_BIAS

        self.layer1 = nn.Sequential(
            nn.ConvTranspose3d(256, 512, 4, 2, 1, bias=use_bias),
            nn.BatchNorm3d(512),
            nn.ReLU(inplace=True)
        )
        self.layer2 = nn.Sequential(
            nn.ConvTranspose3d(512, 128, 4, 2, 1, bias=use_bias),
            nn.BatchNorm3d(128),
            nn.ReLU(inplace=True)
        )
        self.layer3 = nn.Sequential(
            nn.ConvTranspose3d(128, 32, 4, 2, 1, bias=use_bias),
            nn.BatchNorm3d(32),
            nn.ReLU(inplace=True)
        )
        self.layer4 = nn.Sequential(
            nn.ConvTranspose3d(32, 8, 4, 2, 1, bias=use_bias),
            nn.BatchNorm3d(8),
            nn.ReLU(inplace=True)
        )

        # logits head (NO sigmoid)
        self.logits = nn.Conv3d(8, 1, kernel_size=1, bias=True)

    def forward(self, image_features):
        # [B,V,256,7,7] -> iterate views
        image_features = image_features.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(image_features, 1, dim=0)

        raw_features = []
        gen_logits = []

        for f in views:
            f = f.squeeze(0)  # [B,256,7,7]

            # make 3D seed [B,256,2,2,2]
            f_2x2 = F.interpolate(f, size=(2, 2), mode='bilinear', align_corners=False)
            x = f_2x2.unsqueeze(-1).expand(-1, -1, -1, -1, 2)

            x = self.layer1(x)  # 4^3
            x = self.layer2(x)  # 8^3
            x = self.layer3(x)  # 16^3
            x = self.layer4(x)  # 32^3

            v = self.logits(x)             # [B,1,32,32,32] logits
            raw_feat = torch.cat([x, v], dim=1)  # [B,9,32,32,32]

            gen_logits.append(v.squeeze(1))      # [B,32,32,32]
            raw_features.append(raw_feat)

        gen_logits = torch.stack(gen_logits).permute(1, 0, 2, 3, 4).contiguous()
        raw_features = torch.stack(raw_features).permute(1, 0, 2, 3, 4, 5).contiguous()
        return raw_features, gen_logits
