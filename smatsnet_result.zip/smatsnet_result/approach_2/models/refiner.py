# models/refiner.py
import torch
import torch.nn as nn

class Refiner(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        leaky = cfg.NETWORK.LEAKY_VALUE
        use_bias = cfg.NETWORK.TCONV_USE_BIAS

        self.layer1 = nn.Sequential(
            nn.Conv3d(1, 32, 4, padding=2),
            nn.BatchNorm3d(32),
            nn.LeakyReLU(leaky, inplace=True),
            nn.MaxPool3d(2)
        )
        self.layer2 = nn.Sequential(
            nn.Conv3d(32, 64, 4, padding=2),
            nn.BatchNorm3d(64),
            nn.LeakyReLU(leaky, inplace=True),
            nn.MaxPool3d(2)
        )
        self.layer3 = nn.Sequential(
            nn.Conv3d(64, 128, 4, padding=2),
            nn.BatchNorm3d(128),
            nn.LeakyReLU(leaky, inplace=True),
            nn.MaxPool3d(2)
        )
        self.layer4 = nn.Sequential(nn.Linear(8192, 2048), nn.ReLU(inplace=True))
        self.layer5 = nn.Sequential(nn.Linear(2048, 8192), nn.ReLU(inplace=True))
        self.layer6 = nn.Sequential(
            nn.ConvTranspose3d(128, 64, 4, 2, 1, bias=use_bias),
            nn.BatchNorm3d(64),
            nn.ReLU(inplace=True)
        )
        self.layer7 = nn.Sequential(
            nn.ConvTranspose3d(64, 32, 4, 2, 1, bias=use_bias),
            nn.BatchNorm3d(32),
            nn.ReLU(inplace=True)
        )

        # logits head (NO sigmoid)
        self.layer8 = nn.ConvTranspose3d(32, 1, 4, 2, 1, bias=True)

    def forward(self, coarse_logits):
        # coarse_logits: [B,32,32,32]
        x0 = coarse_logits.unsqueeze(1)  # [B,1,32,32,32]

        x16 = self.layer1(x0)            # [B,32,16,16,16]
        x8  = self.layer2(x16)           # [B,64,8,8,8]
        x4  = self.layer3(x8)            # [B,128,4,4,4]

        flat = self.layer4(x4.view(-1, 8192))
        flat = self.layer5(flat)
        x4r  = x4 + flat.view(-1, 128, 4, 4, 4)

        x8r  = x8 + self.layer6(x4r)
        x16r = x16 + self.layer7(x8r)

        out_logits = (x0 + self.layer8(x16r)) * 0.5  # [B,1,32,32,32] logits
        return out_logits.squeeze(1)
# models/refiner.py
import torch
import torch.nn as nn

class Refiner(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        leaky = cfg.NETWORK.LEAKY_VALUE
        use_bias = cfg.NETWORK.TCONV_USE_BIAS

        self.layer1 = nn.Sequential(
            nn.Conv3d(1, 32, 4, padding=2),
            nn.BatchNorm3d(32),
            nn.LeakyReLU(leaky, inplace=True),
            nn.MaxPool3d(2)
        )
        self.layer2 = nn.Sequential(
            nn.Conv3d(32, 64, 4, padding=2),
            nn.BatchNorm3d(64),
            nn.LeakyReLU(leaky, inplace=True),
            nn.MaxPool3d(2)
        )
        self.layer3 = nn.Sequential(
            nn.Conv3d(64, 128, 4, padding=2),
            nn.BatchNorm3d(128),
            nn.LeakyReLU(leaky, inplace=True),
            nn.MaxPool3d(2)
        )
        self.layer4 = nn.Sequential(nn.Linear(8192, 2048), nn.ReLU(inplace=True))
        self.layer5 = nn.Sequential(nn.Linear(2048, 8192), nn.ReLU(inplace=True))
        self.layer6 = nn.Sequential(
            nn.ConvTranspose3d(128, 64, 4, 2, 1, bias=use_bias),
            nn.BatchNorm3d(64),
            nn.ReLU(inplace=True)
        )
        self.layer7 = nn.Sequential(
            nn.ConvTranspose3d(64, 32, 4, 2, 1, bias=use_bias),
            nn.BatchNorm3d(32),
            nn.ReLU(inplace=True)
        )

        # logits head (NO sigmoid)
        self.layer8 = nn.ConvTranspose3d(32, 1, 4, 2, 1, bias=True)

    def forward(self, coarse_logits):
        # coarse_logits: [B,32,32,32]
        x0 = coarse_logits.unsqueeze(1)  # [B,1,32,32,32]

        x16 = self.layer1(x0)            # [B,32,16,16,16]
        x8  = self.layer2(x16)           # [B,64,8,8,8]
        x4  = self.layer3(x8)            # [B,128,4,4,4]

        flat = self.layer4(x4.view(-1, 8192))
        flat = self.layer5(flat)
        x4r  = x4 + flat.view(-1, 128, 4, 4, 4)

        x8r  = x8 + self.layer6(x4r)
        x16r = x16 + self.layer7(x8r)

        out_logits = (x0 + self.layer8(x16r)) * 0.5  # [B,1,32,32,32] logits
        return out_logits.squeeze(1)
