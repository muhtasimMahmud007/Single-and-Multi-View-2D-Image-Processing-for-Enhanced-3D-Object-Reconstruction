# models/ensembler.py
import torch
import torch.nn as nn
import torch.nn.functional as F

class RobustEnsembler(nn.Module):
    """
    Robust ensemble (Mixture-of-Experts gating):
      inputs: list of features from K encoders, each [B,V,256,7,7]
      output: fused [B,V,256,7,7]

    This is more robust than flat concat + single Linear because it can
    dynamically weight each backbone depending on the input/view.
    """
    def __init__(self, n_experts=3, c=256):
        super().__init__()
        self.n_experts = n_experts
        self.c = c

        # Gating: use global pooled descriptor per expert to predict weights
        # weight logits: [B,V,K]
        self.gate_mlp = nn.Sequential(
            nn.Linear(n_experts * c, 256),
            nn.ReLU(inplace=True),
            nn.Linear(256, n_experts)
        )

        # Optional refinement after fusion
        self.refine = nn.Sequential(
            nn.Conv2d(c, c, 3, padding=1, bias=False),
            nn.BatchNorm2d(c),
            nn.ReLU(inplace=True)
        )

    def forward(self, feats_list):
        # feats_list: K tensors [B,V,C,7,7]
        assert len(feats_list) == self.n_experts

        B, V, C, H, W = feats_list[0].shape

        # Build gating input from global pooled per expert
        pooled = []
        for f in feats_list:
            # [B,V,C]
            p = f.mean(dim=(-1, -2))
            pooled.append(p)
        gate_in = torch.cat(pooled, dim=-1)  # [B,V,K*C]

        gate_logits = self.gate_mlp(gate_in)       # [B,V,K]
        gate_w = F.softmax(gate_logits, dim=-1)    # [B,V,K]

        # Weighted sum
        fused = 0.0
        for k in range(self.n_experts):
            wk = gate_w[..., k].view(B, V, 1, 1, 1)   # [B,V,1,1,1]
            fused = fused + wk * feats_list[k]

        # refine per view (2D conv expects [B*V,C,H,W])
        fused_2d = fused.view(B * V, C, H, W)
        fused_2d = self.refine(fused_2d)
        fused = fused_2d.view(B, V, C, H, W)

        return fused
