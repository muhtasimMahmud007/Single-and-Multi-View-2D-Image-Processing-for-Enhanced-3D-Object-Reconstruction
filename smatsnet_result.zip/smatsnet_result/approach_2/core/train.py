# core/train.py
import os
import logging
import random
import torch
import torch.backends.cudnn
import torch.utils.data

import utils.data_loaders
import utils.data_transforms
import utils.helpers

from datetime import datetime as dt
from tensorboardX import SummaryWriter
from time import time

from core.test import test_net
from utils.average_meter import AverageMeter
from utils.amp import get_autocast, get_grad_scaler

from models.encoder import ShuffleNetEncoder, MobileNetV3Encoder, EfficientNetB0Encoder
from models.ensembler import RobustEnsembler
from models.decoder import Decoder
from models.merger import Merger
from models.refiner import Refiner


def train_net(cfg):
    torch.backends.cudnn.benchmark = True

    IMG_SIZE = cfg.CONST.IMG_H, cfg.CONST.IMG_W
    CROP_SIZE = cfg.CONST.CROP_IMG_H, cfg.CONST.CROP_IMG_W

    train_transforms = utils.data_transforms.Compose([
        utils.data_transforms.RandomCrop(IMG_SIZE, CROP_SIZE),
        utils.data_transforms.RandomBackground(cfg.TRAIN.RANDOM_BG_COLOR_RANGE),
        utils.data_transforms.ColorJitter(cfg.TRAIN.BRIGHTNESS, cfg.TRAIN.CONTRAST, cfg.TRAIN.SATURATION),
        utils.data_transforms.RandomNoise(cfg.TRAIN.NOISE_STD),
        utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
        utils.data_transforms.RandomFlip(),
        utils.data_transforms.RandomPermuteRGB(),
        utils.data_transforms.ToTensor(),
    ])

    val_transforms = utils.data_transforms.Compose([
        utils.data_transforms.CenterCrop(IMG_SIZE, CROP_SIZE),
        utils.data_transforms.RandomBackground(cfg.TEST.RANDOM_BG_COLOR_RANGE),
        utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
        utils.data_transforms.ToTensor(),
    ])

    train_dataset_loader = utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TRAIN_DATASET](cfg)
    val_dataset_loader = utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TEST_DATASET](cfg)

    train_loader = torch.utils.data.DataLoader(
        dataset=train_dataset_loader.get_dataset(
            utils.data_loaders.DatasetType.TRAIN, cfg.CONST.N_VIEWS_RENDERING, train_transforms
        ),
        batch_size=cfg.CONST.BATCH_SIZE,
        num_workers=cfg.CONST.NUM_WORKER,
        pin_memory=True,
        shuffle=True,
        drop_last=True
    )

    val_loader = torch.utils.data.DataLoader(
        dataset=val_dataset_loader.get_dataset(
            utils.data_loaders.DatasetType.VAL, cfg.CONST.N_VIEWS_RENDERING, val_transforms
        ),
        batch_size=1,
        num_workers=cfg.CONST.NUM_WORKER,
        pin_memory=True,
        shuffle=False
    )

    # ---------------- Models ----------------
    enc_shuf = ShuffleNetEncoder(cfg, variant="x0_5", pretrained=True)
    enc_mnv3 = MobileNetV3Encoder(cfg, pretrained=True)
    enc_eff  = EfficientNetB0Encoder(cfg, pretrained=True)

    ensembler = RobustEnsembler(n_experts=3, c=256)
    decoder = Decoder(cfg)   # outputs logits volumes per view
    merger = Merger(cfg)     # logits in/logits out
    refiner = Refiner(cfg)   # logits in/logits out

    # init weights for non-pretrained parts
    ensembler.apply(utils.helpers.init_weights)
    decoder.apply(utils.helpers.init_weights)
    merger.apply(utils.helpers.init_weights)
    refiner.apply(utils.helpers.init_weights)

    if torch.cuda.is_available():
        enc_shuf = torch.nn.DataParallel(enc_shuf).cuda()
        enc_mnv3 = torch.nn.DataParallel(enc_mnv3).cuda()
        enc_eff  = torch.nn.DataParallel(enc_eff).cuda()
        ensembler = torch.nn.DataParallel(ensembler).cuda()
        decoder = torch.nn.DataParallel(decoder).cuda()
        merger = torch.nn.DataParallel(merger).cuda()
        refiner = torch.nn.DataParallel(refiner).cuda()

    def forward_features(rendering_images):
        f1 = enc_shuf(rendering_images)
        f2 = enc_mnv3(rendering_images)
        f3 = enc_eff(rendering_images)
        fused = ensembler([f1, f2, f3])  # [B,V,256,7,7]
        return fused

    # AMP + loss
    autocast_cm = get_autocast()
    scaler = get_grad_scaler()
    loss_fn = torch.nn.BCEWithLogitsLoss()  # AMP-safe [web:225]

    # single optimizer
    all_params = (
        list(enc_shuf.parameters()) +
        list(enc_mnv3.parameters()) +
        list(enc_eff.parameters()) +
        list(ensembler.parameters()) +
        list(decoder.parameters()) +
        list(merger.parameters()) +
        list(refiner.parameters())
    )

    if cfg.TRAIN.POLICY.lower() == "adam":
        optimizer = torch.optim.Adam(all_params, lr=cfg.TRAIN.LEARNING_RATE, betas=cfg.TRAIN.BETAS, foreach=False)
    else:
        optimizer = torch.optim.SGD(all_params, lr=cfg.TRAIN.LEARNING_RATE, momentum=cfg.TRAIN.MOMENTUM)

    scheduler = torch.optim.lr_scheduler.MultiStepLR(
        optimizer, milestones=cfg.TRAIN.LR_MILESTONES, gamma=cfg.TRAIN.GAMMA
    )

    # output dirs
    timestamp = dt.now().isoformat().replace(':', '-')
    output_dir = os.path.join(cfg.DIR.OUT_PATH, '%s', timestamp)
    cfg.DIR.LOGS = output_dir % 'logs'
    cfg.DIR.CHECKPOINTS = output_dir % 'checkpoints'
    os.makedirs(cfg.DIR.LOGS, exist_ok=True)
    os.makedirs(cfg.DIR.CHECKPOINTS, exist_ok=True)

    train_writer = SummaryWriter(os.path.join(cfg.DIR.LOGS, 'train'))
    val_writer = SummaryWriter(os.path.join(cfg.DIR.LOGS, 'test'))

    # resume
    init_epoch = 0
    best_iou = -1
    best_epoch = -1

    if 'WEIGHTS' in cfg.CONST and cfg.TRAIN.RESUME_TRAIN:
        ckpt = torch.load(cfg.CONST.WEIGHTS, map_location='cpu')
        init_epoch = ckpt.get('epoch_idx', 0)
        best_iou = ckpt.get('best_iou', -1)
        best_epoch = ckpt.get('best_epoch', -1)

        enc_shuf.load_state_dict(ckpt['enc_shuf'])
        enc_mnv3.load_state_dict(ckpt['enc_mnv3'])
        enc_eff.load_state_dict(ckpt['enc_eff'])
        ensembler.load_state_dict(ckpt['ensembler'])
        decoder.load_state_dict(ckpt['decoder'])
        merger.load_state_dict(ckpt['merger'])
        refiner.load_state_dict(ckpt['refiner'])

        if 'optimizer' in ckpt:
            optimizer.load_state_dict(ckpt['optimizer'])
        if 'scaler' in ckpt:
            scaler.load_state_dict(ckpt['scaler'])

        logging.info('Resumed from %s (epoch=%d)', cfg.CONST.WEIGHTS, init_epoch)

    # ---------------- Train loop ----------------
    for epoch_idx in range(init_epoch, cfg.TRAIN.NUM_EPOCHS):
        batch_time = AverageMeter()
        data_time = AverageMeter()
        ed_losses = AverageMeter()
        rf_losses = AverageMeter()

        enc_shuf.train(); enc_mnv3.train(); enc_eff.train()
        ensembler.train(); decoder.train(); merger.train(); refiner.train()

        end = time()
        n_batches = len(train_loader)

        for batch_idx, (_, _, rendering_images, gt_volumes) in enumerate(train_loader):
            data_time.update(time() - end)

            rendering_images = utils.helpers.var_or_cuda(rendering_images)
            gt_volumes = utils.helpers.var_or_cuda(gt_volumes)

            optimizer.zero_grad(set_to_none=True)

            with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
                fused_feats = forward_features(rendering_images)           # [B,V,256,7,7]
                raw_features, view_logits = decoder(fused_feats)           # view_logits [B,V,32,32,32] logits

                if cfg.NETWORK.USE_MERGER and epoch_idx >= cfg.TRAIN.EPOCH_START_USE_MERGER:
                    fused_logits = merger(raw_features, view_logits)       # [B,32,32,32] logits
                else:
                    fused_logits = torch.mean(view_logits, dim=1)          # [B,32,32,32] logits

                encoder_loss = loss_fn(fused_logits, gt_volumes) * 10

                if cfg.NETWORK.USE_REFINER and epoch_idx >= cfg.TRAIN.EPOCH_START_USE_REFINER:
                    refined_logits = refiner(fused_logits)                 # logits
                    refiner_loss = loss_fn(refined_logits, gt_volumes) * 10
                else:
                    refiner_loss = encoder_loss

                loss = refiner_loss

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            ed_losses.update(encoder_loss.item())
            rf_losses.update(refiner_loss.item())

            itr = epoch_idx * n_batches + batch_idx
            train_writer.add_scalar('Loss/EncoderDecoder_Batch', encoder_loss.item(), itr)
            train_writer.add_scalar('Loss/Refiner_Batch', refiner_loss.item(), itr)

            batch_time.update(time() - end)
            end = time()

            logging.info('[E %d/%d][B %d/%d] BT=%.3f DT=%.3f EDL=%.4f RL=%.4f',
                         epoch_idx + 1, cfg.TRAIN.NUM_EPOCHS, batch_idx + 1, n_batches,
                         batch_time.val, data_time.val, encoder_loss.item(), refiner_loss.item())

        scheduler.step()

        train_writer.add_scalar('Loss/EncoderDecoder_Epoch', ed_losses.avg, epoch_idx + 1)
        train_writer.add_scalar('Loss/Refiner_Epoch', rf_losses.avg, epoch_idx + 1)

        iou = test_net(cfg, epoch_idx + 1, val_loader, val_writer,
                       enc_shuf=enc_shuf, enc_mnv3=enc_mnv3, enc_eff=enc_eff,
                       ensembler=ensembler, decoder=decoder, merger=merger, refiner=refiner)

        is_best = iou > best_iou
        if is_best:
            best_iou = iou
            best_epoch = epoch_idx

        if ((epoch_idx + 1) % cfg.TRAIN.SAVE_FREQ == 0) or is_best:
            fname = 'checkpoint-best.pth' if is_best else ('checkpoint-epoch-%03d.pth' % (epoch_idx + 1))
            out_path = os.path.join(cfg.DIR.CHECKPOINTS, fname)

            ckpt = {
                'epoch_idx': epoch_idx,
                'best_iou': best_iou,
                'best_epoch': best_epoch,
                'enc_shuf': enc_shuf.state_dict(),
                'enc_mnv3': enc_mnv3.state_dict(),
                'enc_eff': enc_eff.state_dict(),
                'ensembler': ensembler.state_dict(),
                'decoder': decoder.state_dict(),
                'merger': merger.state_dict(),
                'refiner': refiner.state_dict(),
                'optimizer': optimizer.state_dict(),
                'scaler': scaler.state_dict(),
            }
            torch.save(ckpt, out_path)
            logging.info('Saved checkpoint: %s', out_path)

    train_writer.close()
    val_writer.close()
