# core/test.py
import json
import logging
import numpy as np
import torch
import torch.utils.data

import utils.data_loaders
import utils.data_transforms
import utils.helpers

from utils.average_meter import AverageMeter
from utils.amp import get_autocast

from models.encoder import ShuffleNetEncoder, MobileNetV3Encoder, EfficientNetB0Encoder
from models.ensembler import RobustEnsembler
from models.decoder import Decoder
from models.merger import Merger
from models.refiner import Refiner


def test_net(cfg, epoch_idx=-1, test_data_loader=None, test_writer=None,
             enc_shuf=None, enc_mnv3=None, enc_eff=None,
             ensembler=None, decoder=None, merger=None, refiner=None):

    autocast_cm = get_autocast()
    loss_fn = torch.nn.BCEWithLogitsLoss()

    with open(cfg.DATASETS[cfg.DATASET.TEST_DATASET.upper()].TAXONOMY_FILE_PATH, encoding='utf-8') as f:
        taxonomies = json.loads(f.read())
    taxonomies = {t['taxonomy_id']: t for t in taxonomies}

    if test_data_loader is None:
        IMG_SIZE = cfg.CONST.IMG_H, cfg.CONST.IMG_W
        CROP_SIZE = cfg.CONST.CROP_IMG_H, cfg.CONST.CROP_IMG_W
        test_transforms = utils.data_transforms.Compose([
            utils.data_transforms.CenterCrop(IMG_SIZE, CROP_SIZE),
            utils.data_transforms.RandomBackground(cfg.TEST.RANDOM_BG_COLOR_RANGE),
            utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
            utils.data_transforms.ToTensor(),
        ])
        dataset_loader = utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TEST_DATASET](cfg)
        test_data_loader = torch.utils.data.DataLoader(
            dataset=dataset_loader.get_dataset(utils.data_loaders.DatasetType.TEST, cfg.CONST.N_VIEWS_RENDERING, test_transforms),
            batch_size=1, num_workers=cfg.CONST.NUM_WORKER, pin_memory=True, shuffle=False
        )

    # build/load models if not injected
    if enc_shuf is None:
        enc_shuf = ShuffleNetEncoder(cfg, variant="x0_5", pretrained=False)
        enc_mnv3 = MobileNetV3Encoder(cfg, pretrained=False)
        enc_eff  = EfficientNetB0Encoder(cfg, pretrained=False)
        ensembler = RobustEnsembler(n_experts=3, c=256)
        decoder = Decoder(cfg)
        merger = Merger(cfg)
        refiner = Refiner(cfg)

        if torch.cuda.is_available():
            enc_shuf = torch.nn.DataParallel(enc_shuf).cuda()
            enc_mnv3 = torch.nn.DataParallel(enc_mnv3).cuda()
            enc_eff  = torch.nn.DataParallel(enc_eff).cuda()
            ensembler = torch.nn.DataParallel(ensembler).cuda()
            decoder = torch.nn.DataParallel(decoder).cuda()
            merger = torch.nn.DataParallel(merger).cuda()
            refiner = torch.nn.DataParallel(refiner).cuda()

        ckpt = torch.load(cfg.CONST.WEIGHTS, map_location='cpu')
        enc_shuf.load_state_dict(ckpt['enc_shuf'])
        enc_mnv3.load_state_dict(ckpt['enc_mnv3'])
        enc_eff.load_state_dict(ckpt['enc_eff'])
        ensembler.load_state_dict(ckpt['ensembler'])
        decoder.load_state_dict(ckpt['decoder'])
        merger.load_state_dict(ckpt['merger'])
        refiner.load_state_dict(ckpt['refiner'])

    def forward_features(rendering_images):
        f1 = enc_shuf(rendering_images)
        f2 = enc_mnv3(rendering_images)
        f3 = enc_eff(rendering_images)
        return ensembler([f1, f2, f3])

    enc_shuf.eval(); enc_mnv3.eval(); enc_eff.eval()
    ensembler.eval(); decoder.eval(); merger.eval(); refiner.eval()

    encoder_losses = AverageMeter()
    refiner_losses = AverageMeter()
    test_iou = {}

    for sample_idx, (taxonomy_id, sample_name, rendering_images, gt) in enumerate(test_data_loader):
        tid = taxonomy_id[0] if isinstance(taxonomy_id[0], str) else taxonomy_id[0].item()
        sname = sample_name[0]

        with torch.no_grad():
            rendering_images = utils.helpers.var_or_cuda(rendering_images)
            gt = utils.helpers.var_or_cuda(gt)

            with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
                feats = forward_features(rendering_images)
                raw, view_logits = decoder(feats)

                if cfg.NETWORK.USE_MERGER and epoch_idx >= cfg.TRAIN.EPOCH_START_USE_MERGER:
                    fused_logits = merger(raw, view_logits)
                else:
                    fused_logits = torch.mean(view_logits, dim=1)

                ed_loss = loss_fn(fused_logits, gt) * 10

                if cfg.NETWORK.USE_REFINER and epoch_idx >= cfg.TRAIN.EPOCH_START_USE_REFINER:
                    refined_logits = refiner(fused_logits)
                    rf_loss = loss_fn(refined_logits, gt) * 10
                    logits = refined_logits
                else:
                    rf_loss = ed_loss
                    logits = fused_logits

            encoder_losses.update(ed_loss.item())
            refiner_losses.update(rf_loss.item())

            prob = torch.sigmoid(logits)
            sample_iou = []
            for th in cfg.TEST.VOXEL_THRESH:
                vol = torch.ge(prob, th).float()
                inter = torch.sum(vol.mul(gt)).float()
                union = torch.sum(torch.ge(vol.add(gt), 1)).float()
                sample_iou.append((inter / union).item())

            if tid not in test_iou:
                test_iou[tid] = {'n_samples': 0, 'iou': []}
            test_iou[tid]['n_samples'] += 1
            test_iou[tid]['iou'].append(sample_iou)

            logging.info('Test[%d] %s/%s IoU=%s', sample_idx + 1, tid, sname, ['%.4f' % x for x in sample_iou])

    n_samples = len(test_data_loader)
    mean_iou = []
    for tid in test_iou:
        test_iou[tid]['iou'] = np.mean(test_iou[tid]['iou'], axis=0)
        mean_iou.append(test_iou[tid]['iou'] * test_iou[tid]['n_samples'])
    mean_iou = np.sum(mean_iou, axis=0) / n_samples
    max_iou = float(np.max(mean_iou))

    if test_writer is not None and epoch_idx >= 0:
        test_writer.add_scalar('Loss/EncoderDecoder_Epoch', encoder_losses.avg, epoch_idx)
        test_writer.add_scalar('Loss/Refiner_Epoch', refiner_losses.avg, epoch_idx)
        test_writer.add_scalar('IoU/max', max_iou, epoch_idx)

    return max_iou
