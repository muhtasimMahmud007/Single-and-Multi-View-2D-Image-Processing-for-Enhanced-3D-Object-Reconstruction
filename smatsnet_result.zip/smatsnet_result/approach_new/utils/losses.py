import torch
import torch.nn as nn
import torch.nn.functional as F

class DiceLoss(nn.Module):
    """
    Dice loss for binary occupancy.
    Uses sigmoid inside; expects logits as input.
    """
    def __init__(self, eps=1e-6):
        super().__init__()
        self.eps = eps

    def forward(self, logits, target):
        # logits/target: [B, D, H, W]
        prob = torch.sigmoid(logits)
        prob = prob.reshape(prob.size(0), -1)
        target = target.reshape(target.size(0), -1)

        inter = (prob * target).sum(dim=1)
        denom = prob.sum(dim=1) + target.sum(dim=1)
        dice = (2.0 * inter + self.eps) / (denom + self.eps)
        return 1.0 - dice.mean()

class BCEDiceLoss(nn.Module):
    """
    BCEWithLogits + Dice (helps with voxel sparsity/imbalance). [web:576]
    """
    def __init__(self, bce_weight=1.0, dice_weight=1.0, pos_weight=None):
        super().__init__()
        self.bce = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
        self.dice = DiceLoss()
        self.bce_w = bce_weight
        self.dice_w = dice_weight

    def forward(self, logits, target):
        return self.bce_w * self.bce(logits, target) + self.dice_w * self.dice(logits, target)
