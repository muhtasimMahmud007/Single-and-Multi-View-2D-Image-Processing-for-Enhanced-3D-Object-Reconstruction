import torch
import torch.nn as nn
import torch.nn.functional as F

class Decoder(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        use_bias = cfg.NETWORK.TCONV_USE_BIAS

        self.t1 = nn.Sequential(nn.ConvTranspose3d(256, 512, 4, 2, 1, bias=use_bias), nn.BatchNorm3d(512), nn.ReLU(True))
        self.t2 = nn.Sequential(nn.ConvTranspose3d(512, 128, 4, 2, 1, bias=use_bias), nn.BatchNorm3d(128), nn.ReLU(True))

        # 16^3 feature stage
        self.t3 = nn.Sequential(nn.ConvTranspose3d(128, 32, 4, 2, 1, bias=use_bias), nn.BatchNorm3d(32), nn.ReLU(True))
        self.head16 = nn.Conv3d(32, 1, 1, bias=True)

        # 32^3 feature stage
        self.t4 = nn.Sequential(nn.ConvTranspose3d(32, 8, 4, 2, 1, bias=use_bias), nn.BatchNorm3d(8), nn.ReLU(True))
        self.head32 = nn.Conv3d(8, 1, 1, bias=True)

    def forward(self, image_features):
        # image_features: [B,V,256,7,7]
        x = image_features.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(x, 1, dim=0)

        feat16_list, feat32_list = [], []
        log16_list, log32_list = [], []

        for f in views:
            f = f.squeeze(0)  # [B,256,7,7]
            f2 = F.interpolate(f, size=(2, 2), mode="bilinear", align_corners=False)
            v = f2.unsqueeze(-1).expand(-1, -1, -1, -1, 2)  # [B,256,2,2,2]

            v = self.t1(v)
            v = self.t2(v)

            feat16 = self.t3(v)                 # [B,32,16,16,16]
            logits16 = self.head16(feat16)      # [B,1,16,16,16]

            feat32 = self.t4(feat16)            # [B,8,32,32,32]
            logits32 = self.head32(feat32)      # [B,1,32,32,32]

            feat16_list.append(feat16)
            feat32_list.append(feat32)
            log16_list.append(logits16.squeeze(1))  # [B,16,16,16]
            log32_list.append(logits32.squeeze(1))  # [B,32,32,32]

        feat16 = torch.stack(feat16_list).permute(1, 0, 2, 3, 4, 5).contiguous()  # [B,V,32,16,16,16]
        feat32 = torch.stack(feat32_list).permute(1, 0, 2, 3, 4, 5).contiguous()  # [B,V,8,32,32,32]
        log16  = torch.stack(log16_list).permute(1, 0, 2, 3, 4).contiguous()      # [B,V,16,16,16]
        log32  = torch.stack(log32_list).permute(1, 0, 2, 3, 4).contiguous()      # [B,V,32,32,32]

        return feat16, feat32, log16, log32
