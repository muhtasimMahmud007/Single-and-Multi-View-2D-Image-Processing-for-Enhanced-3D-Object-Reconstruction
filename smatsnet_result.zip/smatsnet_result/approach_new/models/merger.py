import torch
import torch.nn as nn
import torch.nn.functional as F

class MultiScaleMerger(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        leaky = cfg.NETWORK.LEAKY_VALUE

        # score from 16^3 features (32 channels -> 1 score voxel)
        self.score16 = nn.Sequential(
            nn.Conv3d(32, 16, 3, padding=1, bias=False),
            nn.BatchNorm3d(16),
            nn.LeakyReLU(leaky, inplace=True),
            nn.Conv3d(16, 1, 1, bias=True)
        )

        # score from 32^3 features (8 channels -> 1 score voxel)
        self.score32 = nn.Sequential(
            nn.Conv3d(8, 16, 3, padding=1, bias=False),
            nn.BatchNorm3d(16),
            nn.LeakyReLU(leaky, inplace=True),
            nn.Conv3d(16, 1, 1, bias=True)
        )

    def forward(self, feat16, feat32, log16, log32):
        """
        feat16: [B,V,32,16,16,16]
        feat32: [B,V,8,32,32,32]
        log16:  [B,V,16,16,16]
        log32:  [B,V,32,32,32]
        returns fused logits: (fused16, fused32)
        """
        B, V = log32.shape[:2]

        # --- 32^3 fusion ---
        s32 = []
        for i in range(V):
            si = self.score32(feat32[:, i]).squeeze(1)  # [B,32,32,32]
            s32.append(si)
        s32 = torch.stack(s32, dim=1)                   # [B,V,32,32,32]
        w32 = F.softmax(s32, dim=1)                     # across views
        fused32 = torch.sum(w32 * log32, dim=1)         # [B,32,32,32]

        # --- 16^3 fusion ---
        s16 = []
        for i in range(V):
            si = self.score16(feat16[:, i]).squeeze(1)  # [B,16,16,16]
            s16.append(si)
        s16 = torch.stack(s16, dim=1)                   # [B,V,16,16,16]
        w16 = F.softmax(s16, dim=1)
        fused16 = torch.sum(w16 * log16, dim=1)         # [B,16,16,16]

        return fused16, fused32
