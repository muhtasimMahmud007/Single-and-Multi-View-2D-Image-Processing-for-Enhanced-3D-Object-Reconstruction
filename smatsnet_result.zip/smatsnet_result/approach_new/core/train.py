import os
import logging
import torch
import torch.utils.data
import torch.nn.functional as F

import utils.data_loaders
import utils.data_transforms
import utils.helpers

from datetime import datetime as dt
from tensorboardX import SummaryWriter

from utils.amp import get_autocast, get_grad_scaler
from utils.losses import BCEDiceLoss
from core.test import test_net

from models.encoder import ShuffleNetEncoder, ConvNeXtEncoder, ViTTinyEncoder
from models.ensembler import RobustEnsembler
from models.decoder import Decoder
from models.merger import MultiScaleMerger
from models.refiner import Refiner


def train_net(cfg):
    IMG_SIZE = cfg.CONST.IMG_H, cfg.CONST.IMG_W
    CROP_SIZE = cfg.CONST.CROP_IMG_H, cfg.CONST.CROP_IMG_W

    train_tf = utils.data_transforms.Compose([
        utils.data_transforms.RandomCrop(IMG_SIZE, CROP_SIZE),
        utils.data_transforms.RandomBackground(cfg.TRAIN.RANDOM_BG_COLOR_RANGE),
        utils.data_transforms.ColorJitter(cfg.TRAIN.BRIGHTNESS, cfg.TRAIN.CONTRAST, cfg.TRAIN.SATURATION),
        utils.data_transforms.RandomNoise(cfg.TRAIN.NOISE_STD),
        utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
        utils.data_transforms.RandomFlip(),
        utils.data_transforms.RandomPermuteRGB(),
        utils.data_transforms.ToTensor(),
    ])

    val_tf = utils.data_transforms.Compose([
        utils.data_transforms.CenterCrop(IMG_SIZE, CROP_SIZE),
        utils.data_transforms.RandomBackground(cfg.TEST.RANDOM_BG_COLOR_RANGE),
        utils.data_transforms.Normalize(mean=cfg.DATASET.MEAN, std=cfg.DATASET.STD),
        utils.data_transforms.ToTensor(),
    ])

    train_loader = torch.utils.data.DataLoader(
        dataset=utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TRAIN_DATASET](cfg).get_dataset(
            utils.data_loaders.DatasetType.TRAIN, cfg.CONST.N_VIEWS_RENDERING, train_tf),
        batch_size=cfg.CONST.BATCH_SIZE, num_workers=cfg.CONST.NUM_WORKER,
        pin_memory=True, shuffle=True, drop_last=True
    )

    val_loader = torch.utils.data.DataLoader(
        dataset=utils.data_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TEST_DATASET](cfg).get_dataset(
            utils.data_loaders.DatasetType.VAL, cfg.CONST.N_VIEWS_RENDERING, val_tf),
        batch_size=1, num_workers=cfg.CONST.NUM_WORKER,
        pin_memory=True, shuffle=False
    )

    # Experts: ShuffleNet + ConvNeXt + ViT-Tiny
    enc_shuf = ShuffleNetEncoder(cfg, use_imagenet_weights=True)
    enc_cnx  = ConvNeXtEncoder(cfg, use_imagenet_weights=True)
    enc_vit  = ViTTinyEncoder(cfg, pretrained=True, model_name="vit_tiny_patch16_224")

    ens = RobustEnsembler(n_experts=3, c=256, vit_blocks=1, vit_heads=4, vit_mlp_ratio=2.0, dropout=0.1)

    dec = Decoder(cfg)
    mrg = MultiScaleMerger(cfg)
    rfn = Refiner(cfg)

    ens.apply(utils.helpers.init_weights)
    dec.apply(utils.helpers.init_weights)
    mrg.apply(utils.helpers.init_weights)
    rfn.apply(utils.helpers.init_weights)

    if torch.cuda.is_available():
        enc_shuf = torch.nn.DataParallel(enc_shuf).cuda()
        enc_cnx  = torch.nn.DataParallel(enc_cnx).cuda()
        enc_vit  = torch.nn.DataParallel(enc_vit).cuda()
        ens = torch.nn.DataParallel(ens).cuda()
        dec = torch.nn.DataParallel(dec).cuda()
        mrg = torch.nn.DataParallel(mrg).cuda()
        rfn = torch.nn.DataParallel(rfn).cuda()

    autocast_cm = get_autocast()
    scaler = get_grad_scaler()

    # Optional: can set pos_weight for imbalance; left None by default. [web:576]
    loss_fn = BCEDiceLoss(bce_weight=1.0, dice_weight=1.0, pos_weight=None)

    params = (
        list(enc_shuf.parameters()) + list(enc_cnx.parameters()) + list(enc_vit.parameters()) +
        list(ens.parameters()) + list(dec.parameters()) + list(mrg.parameters()) + list(rfn.parameters())
    )
    opt = torch.optim.Adam(params, lr=cfg.TRAIN.LEARNING_RATE, betas=cfg.TRAIN.BETAS, foreach=False)
    sch = torch.optim.lr_scheduler.MultiStepLR(opt, milestones=cfg.TRAIN.LR_MILESTONES, gamma=cfg.TRAIN.GAMMA)

    ts = dt.now().isoformat().replace(':', '-')
    out_dir = os.path.join(cfg.DIR.OUT_PATH, '%s', ts)
    cfg.DIR.LOGS = out_dir % 'logs'
    cfg.DIR.CHECKPOINTS = out_dir % 'checkpoints'
    os.makedirs(cfg.DIR.LOGS, exist_ok=True)
    os.makedirs(cfg.DIR.CHECKPOINTS, exist_ok=True)

    tr_w = SummaryWriter(os.path.join(cfg.DIR.LOGS, 'train'))
    te_w = SummaryWriter(os.path.join(cfg.DIR.LOGS, 'test'))

    best_iou = -1
    best_epoch = -1

    for epoch in range(cfg.TRAIN.NUM_EPOCHS):
        enc_shuf.train(); enc_cnx.train(); enc_vit.train()
        ens.train(); dec.train(); mrg.train(); rfn.train()

        for b, (_, _, imgs, gt32) in enumerate(train_loader):
            imgs = utils.helpers.var_or_cuda(imgs)
            gt32 = utils.helpers.var_or_cuda(gt32)
            gt16 = F.interpolate(gt32.unsqueeze(1), size=(16, 16, 16), mode="trilinear", align_corners=False).squeeze(1)

            opt.zero_grad(set_to_none=True)

            with autocast_cm(enabled=torch.cuda.is_available(), dtype=torch.float16):
                f1 = enc_shuf(imgs)
                f2 = enc_cnx(imgs)
                f3 = enc_vit(imgs)
                fused2d = ens([f1, f2, f3])

                feat16, feat32, log16, log32 = dec(fused2d)
                fused16, fused32 = mrg(feat16, feat32, log16, log32)

                loss_coarse16 = loss_fn(fused16, gt16)
                loss_coarse32 = loss_fn(fused32, gt32)

                refined32 = rfn(fused32)
                loss_refine = loss_fn(refined32, gt32)

                # weights can be tuned; start conservative
                loss = 0.3 * loss_coarse16 + 1.0 * loss_coarse32 + 1.0 * loss_refine

            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()

            itr = epoch * len(train_loader) + b
            tr_w.add_scalar("Loss/Coarse16", loss_coarse16.item(), itr)
            tr_w.add_scalar("Loss/Coarse32", loss_coarse32.item(), itr)
            tr_w.add_scalar("Loss/Refine32", loss_refine.item(), itr)
            tr_w.add_scalar("Loss/Total", loss.item(), itr)

            if b % 20 == 0:
                logging.info("[E %d][B %d/%d] L16=%.4f L32=%.4f Lref=%.4f L=%.4f",
                             epoch + 1, b + 1, len(train_loader),
                             loss_coarse16.item(), loss_coarse32.item(), loss_refine.item(), loss.item())

        sch.step()

        iou = test_net(cfg, epoch + 1, val_loader, te_w, enc_shuf, enc_cnx, enc_vit, ens, dec, mrg, rfn)
        is_best = iou > best_iou
        if is_best:
            best_iou = iou
            best_epoch = epoch

        if ((epoch + 1) % cfg.TRAIN.SAVE_FREQ == 0) or is_best:
            name = "checkpoint-best.pth" if is_best else f"checkpoint-epoch-{epoch+1:03d}.pth"
            path = os.path.join(cfg.DIR.CHECKPOINTS, name)
            torch.save({
                "epoch": epoch,
                "best_iou": best_iou,
                "best_epoch": best_epoch,
                "enc_shuf": enc_shuf.state_dict(),
                "enc_cnx": enc_cnx.state_dict(),
                "enc_vit": enc_vit.state_dict(),
                "ens": ens.state_dict(),
                "dec": dec.state_dict(),
                "mrg": mrg.state_dict(),
                "rfn": rfn.state_dict(),
                "opt": opt.state_dict(),
                "scaler": scaler.state_dict(),
            }, path)
            logging.info("Saved: %s", path)

    tr_w.close()
    te_w.close()
