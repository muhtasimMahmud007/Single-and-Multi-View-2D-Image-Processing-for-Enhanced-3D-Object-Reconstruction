import torch
import torch.nn as nn
import torch.nn.functional as F

class TinyViTBlock(nn.Module):
    def __init__(self, dim=256, heads=4, mlp_ratio=2.0, dropout=0.1):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(embed_dim=dim, num_heads=heads, dropout=dropout, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        hidden = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, dim),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        h = self.norm1(x)
        a, _ = self.attn(h, h, h)
        x = x + a
        x = x + self.mlp(self.norm2(x))
        return x

class RobustEnsembler(nn.Module):
    """
    3 experts: ShuffleNet + ResNet50 + ConvNeXt
    MoE gating + tiny transformer refinement over 7x7 tokens. [web:358]
    """
    def __init__(self, n_experts=3, c=256, vit_blocks=1, vit_heads=4, vit_mlp_ratio=2.0, dropout=0.1):
        super().__init__()
        self.n_experts = n_experts
        self.c = c

        self.gate = nn.Sequential(
            nn.Linear(n_experts * c, 256),
            nn.ReLU(inplace=True),
            nn.Linear(256, n_experts)
        )

        self.vit = nn.ModuleList([
            TinyViTBlock(dim=c, heads=vit_heads, mlp_ratio=vit_mlp_ratio, dropout=dropout)
            for _ in range(vit_blocks)
        ])

        self.out = nn.Sequential(
            nn.Conv2d(c, c, 3, padding=1, bias=False),
            nn.BatchNorm2d(c),
            nn.ReLU(inplace=True)
        )

    def forward(self, feats_list):
        K = len(feats_list)
        assert K == self.n_experts
        B, V, C, H, W = feats_list[0].shape

        pooled = [f.mean(dim=(-1, -2)) for f in feats_list]  # K*[B,V,C]
        gate_in = torch.cat(pooled, dim=-1)                  # [B,V,K*C]
        w = F.softmax(self.gate(gate_in), dim=-1)            # [B,V,K]

        fused = 0.0
        for k in range(K):
            fused = fused + w[..., k].view(B, V, 1, 1, 1) * feats_list[k]

        L = H * W
        tokens = fused.view(B * V, C, L).transpose(1, 2)     # [B*V,49,256]
        for blk in self.vit:
            tokens = blk(tokens)

        fused = tokens.transpose(1, 2).view(B * V, C, H, W)
        fused = self.out(fused).view(B, V, C, H, W)
        return fused
