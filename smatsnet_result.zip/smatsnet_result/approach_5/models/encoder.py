import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

from torchvision.models import (
    ShuffleNet_V2_X0_5_Weights,
    ShuffleNet_V2_X1_0_Weights,
    ConvNeXt_Tiny_Weights,
    ResNet50_Weights,
)

class _Adapter(nn.Module):
    def __init__(self, in_ch, out_ch=256):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x = F.adaptive_avg_pool2d(x, (7, 7))
        return self.proj(x)  # [B,256,7,7]


class ShuffleNetEncoder(nn.Module):
    def __init__(self, cfg, variant="x0_5", use_imagenet_weights=True):
        super().__init__()
        self.cfg = cfg
        if variant == "x0_5":
            w = ShuffleNet_V2_X0_5_Weights.DEFAULT if use_imagenet_weights else None
            net = models.shufflenet_v2_x0_5(weights=w)
        else:
            w = ShuffleNet_V2_X1_0_Weights.DEFAULT if use_imagenet_weights else None
            net = models.shufflenet_v2_x1_0(weights=w)

        self.backbone = nn.Sequential(*list(net.children())[:-1])
        self.adapter = _Adapter(1024, 256)

    def forward(self, rendering_images):
        x = rendering_images.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(x, 1, dim=0)
        feats = []
        for img in views:
            f = self.backbone(img.squeeze(0))     # [B,1024,?,?]
            feats.append(self.adapter(f))         # [B,256,7,7]
        return torch.stack(feats).permute(1, 0, 2, 3, 4).contiguous()


class ResNet50Encoder(nn.Module):
    """
    ResNet50 layer4 output channels are 2048 in torchvision; adapter -> 256. [web:434]
    """
    def __init__(self, cfg, use_imagenet_weights=True):
        super().__init__()
        self.cfg = cfg
        w = ResNet50_Weights.DEFAULT if use_imagenet_weights else None
        net = models.resnet50(weights=w)

        self.backbone = nn.Sequential(
            net.conv1, net.bn1, net.relu, net.maxpool,
            net.layer1, net.layer2, net.layer3, net.layer4
        )
        self.adapter = _Adapter(2048, 256)

    def forward(self, rendering_images):
        x = rendering_images.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(x, 1, dim=0)
        feats = []
        for img in views:
            f = self.backbone(img.squeeze(0))     # [B,2048,?,?]
            feats.append(self.adapter(f))         # [B,256,7,7]
        return torch.stack(feats).permute(1, 0, 2, 3, 4).contiguous()


class ConvNeXtEncoder(nn.Module):
    """
    ConvNeXt-Tiny from torchvision. [web:378]
    """
    def __init__(self, cfg, use_imagenet_weights=True):
        super().__init__()
        self.cfg = cfg
        w = ConvNeXt_Tiny_Weights.DEFAULT if use_imagenet_weights else None
        net = models.convnext_tiny(weights=w)

        self.backbone = net.features
        self.adapter = _Adapter(768, 256)

    def forward(self, rendering_images):
        x = rendering_images.permute(1, 0, 2, 3, 4).contiguous()
        views = torch.split(x, 1, dim=0)
        feats = []
        for img in views:
            f = self.backbone(img.squeeze(0))     # [B,768,?,?]
            feats.append(self.adapter(f))         # [B,256,7,7]
        return torch.stack(feats).permute(1, 0, 2, 3, 4).contiguous()
